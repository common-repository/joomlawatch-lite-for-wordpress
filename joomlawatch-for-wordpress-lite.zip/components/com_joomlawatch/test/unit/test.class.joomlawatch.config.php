<?php
/**
 * Created by IntelliJ IDEA.
 * User: matej.koval
 * Date: Apr 21, 2010
 * Time: 1:37:59 PM
 * To change this template use File | Settings | File Templates.
 */
require("test.joomlawatch.base.php");

class TestJoomlaWatchConfig extends TestJoomlaWatchBase {

    function testConfigValueInsertion() {
        $joomlaWatchConfig = new JoomlaWatchConfig();
        $testKey = "TEST CONFIG KEY";
        $testValue = "TEST CONFIG VALUE";
        $joomlaWatchConfig->saveConfigValue($testKey, $testValue);
        $this->assertTrue($testValue == $joomlaWatchConfig->getConfigValue($testKey));
        $joomlaWatchConfig->removeConfigValue($testKey, $testValue);
        $this->assertTrue($testValue != $joomlaWatchConfig->getConfigValue($testKey));
    }

}
