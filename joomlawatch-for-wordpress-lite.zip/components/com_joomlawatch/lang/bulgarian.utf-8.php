<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Статистика");
DEFINE('_JW_MENU_GOALS', "Цели");
DEFINE('_JW_MENU_SETTINGS', "Настройки");
DEFINE('_JW_MENU_CREDITS', "Благодарности");
DEFINE('_JW_MENU_FAQ', "Често задавани въпроси");
DEFINE('_JW_MENU_DOCUMENTATION', "Документация");
DEFINE('_JW_MENU_LICENSE', "Лиценз");
DEFINE('_JW_MENU_DONATORS', "Дарители");
DEFINE('_JW_MENU_SUPPORT', "Поддържйте JoomlaWatch и рекламите няма да се показват.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Последни посетители");
DEFINE('_JW_VISITS_BOTS', "Ботове");
DEFINE('_JW_VISITS_CAME_FROM', "Идва от");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Вашият модул JoomlaWach не е публикуван.За това не са записани никакви статистически данни. Отидете в раздел модули и да зададете модул JoomlaWatch - да се публикува във всички страници");
DEFINE('_JW_VISITS_PANE_LOADING', "Зареждане...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Статистика на посещенията през седмицата");
DEFINE('_JW_STATS_WEEK', "Седмица");
DEFINE('_JW_STATS_THIS_WEEK', "Тази седмица");
DEFINE('_JW_STATS_UNIQUE', "Уникални");
DEFINE('_JW_STATS_LOADS', "Зареждания");
DEFINE('_JW_STATS_HITS', "Хитове");
DEFINE('_JW_STATS_TODAY', "Днес");
DEFINE('_JW_STATS_FOR', "за");
DEFINE('_JW_STATS_ALL_TIME', "За целият период");
DEFINE('_JW_STATS_EXPAND', "Подробно");
DEFINE('_JW_STATS_COLLAPSE', "Съкратено");
DEFINE('_JW_STATS_URI', "Страници");
DEFINE('_JW_STATS_COUNTRY', "Държави");
DEFINE('_JW_STATS_USERS', "Потребители");
DEFINE('_JW_STATS_REFERERS', "Препратки");
DEFINE('_JW_STATS_IP', "IP адреси");
DEFINE('_JW_STATS_BROWSER', "Браузер");
DEFINE('_JW_STATS_OS', "ОС");
DEFINE('_JW_STATS_KEYWORDS', "Ключови думи");
DEFINE('_JW_STATS_GOALS', "Цели");
DEFINE('_JW_STATS_TOTAL', "Общо");
DEFINE('_JW_STATS_DAILY', "За определен ден");
DEFINE('_JW_STATS_DAILY_TITLE', "Дневна статистика за");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Обща статистика");
DEFINE('_JW_STATS_LOADING', "Зареждане...");
DEFINE('_JW_STATS_LOADING_WAIT', "Зареждане... моля изчакайте");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Блокиран IP адрес");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Въведете ръчно IP адреса, който искате да блокирате.");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Напишете IP адреса, който искате да блокирате. (напр. 217.242.11.54 или 217.* или 217.242.* за блокиране на обсега след звездичката)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Превключване на блокирани IP адреси");
DEFINE('_JW_STATS_PANE_LOADING', "Зареждам статистиката...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Настройки");
DEFINE('_JW_SETTINGS_DEFAULT', "Стандартни");
DEFINE('_JW_SETTINGS_SAVE', "Запомни");
DEFINE('_JW_SETTINGS_APPEARANCE', "Външен вид");
DEFINE('_JW_SETTINGS_FRONTEND', "Изглед на сайта");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "История и изпълнения");
DEFINE('_JW_SETTINGS_ADVANCED', "Разширения");
DEFINE('_JW_SETTINGS_IGNORE', "Игнориране");
DEFINE('_JW_SETTINGS_BLOCKING', "Блокиране");
DEFINE('_JW_SETTINGS_EXPERT', "Експерт");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Наистина ли искате да възстановите всички статистически данни и посетители?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Въстановяване на всички данни");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Въстановяване на всички статистически данни &amp; и посетители");
DEFINE('_JW_SETTINGS_LANGUAGE', "Език");
DEFINE('_JW_SETTINGS_SAVED', "Настройките бяха съхранени");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Добавете Вашия IP адрес");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "в списъка");

# Other / mostly general
DEFINE('_JW_TITLE', "AJAX монитор за Joomla");
DEFINE('_JW_BACK', "Назад");
DEFINE('_JW_ACCESS_DENIED', "Нямате права за достъп");
DEFINE('_JW_LICENSE_AGREE', "Съгласен съм с настоящите условия &amp; и условията по-горе");
DEFINE('_JW_LICENSE_CONTINUE', "Продължи");
DEFINE('_JW_SUCCESS', "Операцията приключи успешно");
DEFINE('_JW_RESET_SUCCESS', "Всички статистически данни и данни за посетителите бяхя изтрити");
DEFINE('_JW_RESET_ERROR', "Данните не бяха изтрити, нещо не се получи");
DEFINE('_JW_CREDITS_TITLE', "Благодарности");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Дневни и седмични статистически данни за:");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX достъп отхвърлен: Моля, разгледайте статистиката на домейна, който сте посочили в configuration.php на Джумла - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Може би просто сте забравили да въведете WWW. преди името на домейна в браузъра. Javascript търси садържание ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "от");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "това го принуждава да си мисли,че това е друг домейн");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Вземете най-новия код на това разширение от");
DEFINE('_JW_HEADER_CAST_YOUR', "Изпратете своя");
DEFINE('_JW_HEADER_VOTE', "Глас");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Кликнете за да отворите tooltip прозореца");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Отидете с мишката на tooltip за да отворите прозореца");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "Увеличение &apos; от вчера");
DEFINE('_JW_TOOLTIP_HELP', "Отвари онлайн помощ за");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Затвори този прозорец");
DEFINE('_JW_TOOLTIP_PRINT', "Печат");

# Goals
DEFINE('_JW_GOALS_INSERT', "Добавяне на нова цел");
DEFINE('_JW_GOALS_UPDATE', "Редактиране на цел номер");
DEFINE('_JW_GOALS_ACTION', "Действие");
DEFINE('_JW_GOALS_TITLE', "Заглавие на Нова цел");
DEFINE('_JW_GOALS_NEW', "Нова цел");
DEFINE('_JW_GOALS_RELOAD', "Обновяване");
DEFINE('_JW_GOALS_ADVANCED', "Разширено");
DEFINE('_JW_GOALS_NAME', "Име");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "URI състояние");
DEFINE('_JW_GOALS_URI_INVERSED', "URI обратно състояние");
DEFINE('_JW_GOALS_GET_VAR', "GET променлива");
DEFINE('_JW_GOALS_GET_CONDITION', "GET състояние");
DEFINE('_JW_GOALS_POST_VAR', "POST променлива");
DEFINE('_JW_GOALS_POST_CONDITION', "POST състояние");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Заглавие-състояние");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Потребителско име-състояние");
DEFINE('_JW_GOALS_IP_CONDITION', "IP състояние");
DEFINE('_JW_GOALS_IP_INVERSED', "IP обратно състояние");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Идва от състояние");
DEFINE('_JW_GOALS_BLOCK', "Блокирай");
DEFINE('_JW_GOALS_REDIRECT', "Пренасочи на URL");
DEFINE('_JW_GOALS_HITS', "Посещения");
DEFINE('_JW_GOALS_ENABLED', "Разрешени");
DEFINE('_JW_GOALS_EDIT', "Редактиране");
DEFINE('_JW_GOALS_DELETE', "Изтриване");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Вие ще загубите всички съществуващи статистически данни за тази цел. Наистина ли искате да изтриете всичко?");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Държава");
DEFINE('_JW_FRONTEND_VISITORS', "Посетители");
DEFINE('_JW_FRONTEND_TODAY', "Днес");
DEFINE('_JW_FRONTEND_YESTERDAY', "Вчера");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Тази седмица");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Миналата седмица");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Този месец");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Миналият месец");
DEFINE('_JW_FRONTEND_TOTAL', "Общо");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch е в debug режим. По този начин ще могат да се определят причините за грешки. За да изключите, моля, променете стойността JOOMLAWATCH_DEBUG в /components/com_joomlawatch/config.php от 1 на 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Максимален брой на редовете на данни след декомпресия в областта на статистиката");
DEFINE('_JW_DESC_STATS_IP_HITS', "Всички IP адреси, които имат по-малко хитове от предишните дни, ще бъдат изтрити от историята на IP адреси.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Всички URL адреси, които са по-малко хитове от предишните дни, ще бъде заличена от историята URL адреси.");
DEFINE('_JW_DESC_IGNORE_IP', "Игнориране на IP адрес в статистиката.Всеки адрес отделно на нов ред. Можете да използвате звездичка. <br/>Например. 192.* ще игнорира 192.168.51.31, 192.168.16.2, итн..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Продължителност на подновяване на посетителите в левия панел, в милисекунди, по подразбиране 2000, бъдете внимателни с тази настройка.За да има ефект, обновете през администрацията интерфейса в JoomlaWatch.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Продължителност на подновяване на статистиката в десния панел в милисекунди, стандартно 2000, бъдете внимателни с тази настройка. а да има ефект, обновете през администрацията интерфейса в JoomlaWatch.");
DEFINE('_JW_DESC_MAXID_BOTS', "Колко записа да се съхраняват в базата данни.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Колко записа на посетителите да се съхраняват в базата данни.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Колко записа да се видат в левия панел в администраторския интерфейс.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Колко посетителите да се виждат в левия панел в администраторския интерфейс.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Максимум символи, които ще бъдат показани при дълги заглавия и URI адреси");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Максимум символи, които ще да бъдат показани при дълги заглавия в десния статистически панел");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Брой дни през които да се запази общата история на статистическите данни в базата данни. 0 = безкрайност.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Ако сте в различна часова зона от сървъра ви, на който хоствате сайта си.(Въведете положително или отрицателно число, като разликата в часова зона)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Промяната в рамките на седмицата, Timestamp/(3600*24*7) връща номера на седмицата от 1.1.1970, тази промяна е корекция на седмицата, започваща с понеделник. При нормални случаи, не е необходимо да се променя.");
DEFINE('_JW_DESC_DAY_OFFSET', "Промяната в рамките на деня, Шimestamp/(3600*24) връща датата на деня от 1.1.1970, тази промяна е корекция, за да започва денят от 00:00. При нормални случаи, не е необходимо да се променя");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(функционира в рекламата-безплатната версия)</b> За да използвате празна икона 1x1px в предния край");
DEFINE('_JW_DESC_IP_STATS', "Използване на IP адрес в статистиката. В някои страни, IP адреса се счита за лични данни. Използвайте на свой собствен риск.");
DEFINE('_JW_DESC_HIDE_ADS', "Тази настройка скрива рекламите, ако те наистина ви дразнят.С поддържането им, Вие подкрепяте по-нататъшното развитие на този инструмент. Благодаря.");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Ако искате да се покажат непроверените в отделен прозорец карти и схеми, поставете курсора върху иконите, вместо да кликнете.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "По подразбиране тази настройка е 'REDIRECT_URL', ако използвате url rewriting, можете да пормените на 'SCRIPT_URL' ако във вашата статистика се показва само index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Собщение, което показва допълнителна информация по някакъв повод, защо са тези потребители блокирани.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Ширина на прозореца в tooltip");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Височина на прозореца в tooltip");
DEFINE('_JW_DESC_TOOLTIP_URL', "Тук можете да напишете всякакъв адрес за визуализиране на посетителския IP адрес.{ip} ще бъде заменен от реалният IP адреса на потребителя. Например: http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Можете да въведете всякакъв URI, които искате да бъде игнориран от статистика. Можете да използвате заместващи символи (* и ?) тук. Напр. : /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Задайте името на целта. Това име ще видите в статистиката.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Това, което се намира непосредствено след адреса на вашия домейн. За http://www.codegravity.com/projects/ е URI: /projects/ (Пример: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET променлива е обикновено това, което виждате в URL обикновено след  знака ? или & amp; например: http://www.codegravity.com/index.php?<u>име</u>u=peter&amp;<u>фамилия</u>=smith.Можете също да използвате <u>*</u> в това поле, за всички GET променливи.(Пример: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Тук можете да определите на какво да се равни променливата в предишното поле.(Пример: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Нещо подобно, но спазваме стойностите, вписани във формуляра. Така, че ако имате на уебсайта си формуляр, който има полето за въвеждане <input type='text' name='<u>регистрация</u>' /> &gt;. (Пример: <b>expert*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Стойност, която е равна на променливата в предходното POST поле. Напр. Искаме да видим дали потребителят е направил опит за въвеждане в полето стойност на Java.(Пример: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Заглавие на страница, която да съответства. (Пример: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Име на влезлият потребител, за когото целта се прилага. (Пример: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP адрес, от който идва посетителят. (Пример: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL, от който идва посетителят. (Пример: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Ако тези условия са изпълнени, можете за пренасочите потребителя  към адрес по Ваш избор. Има по-висок приоритет, отколкото 'блокиран': (Пример: <b>http://www.codegravity.com/chod-prec.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Колко символа максимум да се показват в таблицата за дълги имена");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Препратката до codegravity.com, можете да промените тази настройка, но оценяваме, ако тя остане.Благодаря");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Преглед на общата статистика в модула на сайта. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Ако искате  да пренаредите реда на Посетители/Държави в модула на страницата. Махнете го, статистиката на Посетителите ще се покаже на първо място,а след това Държави.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Брой на държавите, които желаете да се показват в модула на сайта");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Преглед на държавите в модула на сайта. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Време в секунди колко често да се актуализират статистическите данни на държавите в модула на сайта");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Време в секунди колко често да се актуализира статистиката за посетителите в модула на сайта");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Преглед на посетителите на сайта за: Днес. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Преглед на посетителите на сайта за: Вчера. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Преглед на посетителите на сайта за: Тази седмица. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Преглед на посетителите на сайта за: Миналата седмиа. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Преглед на посетителите на сайта за: Този месец. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Преглед на посетителите на сайта за: Миналият месец. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Преглед на посетителите на сайта Общо след инсталацията на JoomlaWatch. Ако промените настройките, трябва да изчакате да изтече времето в CACHE_FRONTEND_  за да настъпят промените.");
DEFINE('_JW_DESC_LANGUAGE', "Езиков файл, който се използва. Езиковите файлове се намират в /components/com_joomlawatch/lang/. За да добавите нов език, първо се уверете, че той не е вече на страниците на този проект. Ако там го няма, копирайте english.php и го преименувайте на mojjazyk.php например и го поставете на по-горния адрес. Преведете всички изрази в дясно. Най-добре е да използвате кодировка UTF-8");
DEFINE('_JW_DESC_GOALS', "Целите Ви позволяват да се определят специални параметри. Ако с тези параметри сте съгласни, производителността на брояча се увеличава. По този начин можете да наблюдавате дали един посетител е посещавал специфични URL, дали е изпратил конкретна стойност във формуляра, има специфично име или идва от някой адрес. Можете да блокирате такъв посетител или да го пренасочете към специален URL адрес.");
DEFINE('_JW_DESC_GOALS_INSERT', "Във всички полета освен имена може да използвате символите * и ?. Например: ?ear (комбинира: near, tear, ..),  p*r (комбинира: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Настройте на 1, ако искате да блокирате даден посетител, който отговаря на критериите. Няма да виждате останалата част от съдържанието на сайта, само съобщение за неговото блокиране - без пренасочване, и неговия IP адрес ще бъде добавен към списъка на блокираните в статистиката. (Пример: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Изисквания на дадената държава");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Държави обратно състояние");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Двубуквеният код на дадена държава (Напр.: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Вътрешен");
DEFINE('_JW_STATS_FROM',"От");
DEFINE('_JW_STATS_TO',"До");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Добави цел");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Добави цел за тази държава");
DEFINE('_JW_MENU_REPORT_BUG',"Напиши за грешки или дай предложение");
DEFINE('_JW_GOALS_COUNTRY',"Държава");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Ако искате имената на държавите да са изписани с главни букви на сайта (Напр.: GERMANY, UNITED KINGDOM вместо Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Време в секунди колко често да се актуализират статистическите данни на потребителите в сайта");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Първоначална стойност 'Общо:' на сайта. Полезно, ако сте преминали от друг статистически инструмент. (Напр. 20000). Ако не искате да използвате тази функция попълнете 0.");
DEFINE('_JW_DESC_IGNORE_USER', "Игнорирай потребитилите от този textbox. Потребителско име он-лайн. (Напр.: myself {нов ред} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Най-активните потребители към днешна дата от общият брой");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Включва блокиране на изброените спам думи, показани по-долу?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Най-използваните спам думи, използвани в спам ботове. Можете да използвате * и ?. (Напр.: ph?rmac*).Ако в настройките по-горе е разрешено, JoomlaWatch ще провери дали атакуващия изпратен формуляр ( HTTP POST заявка) към сайта Ви съвпада с една от тези думи. (Прилага се само за сайт под Joomla – форуми, коментари, това е доста ефективен начин за премахване на спам ботове, които се опитват да изпращат всякакви възможни формуляри.");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Анти-Спам");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Линка, намиращ се в лицевия потребителски модул, който Ви позволява да посочите специфичен URL,който е отворен, когато потребителят кликне върху потребителското си име. Трябва да съдържа низа {user}, който ще бъде заменен с истинското име на потребителя. (Напр. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Ключови фрази");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Максимални стойности в раздела История(Example: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "В посещения показвай само последната посетена страница, не всички");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "В посещения скрий повтарящи се заглавия на посетени вече страници");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Максимален брой на посетителите да се запазят в базата данни История на посещенията. Бъдете внимателни с тази настройка, ако имате голям трафик, може да расте много по-бързо. Винаги проверявайте статуса колко данни в таблицата за историята се съдържат.");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Включете таблиците в базата данни за деинсталиране. Изберете тази опция, преди да деинсталирате, ако правите ъпгрейд и искате да запазите данните си.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Ще получите вечер имейли с отчети за предходния ден, които можете да прочетете на сутринта");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Email адреса, на който ще получите тези отчети");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Само включени редове в електронна поща, доклади, където този процент е по-висока от {value}. Задайте 0, ако не искате да ползвате тази функция <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Включва само <b> за един ден </b> положителна промяна на стойността в имейла за отчитане на по-висок  {value} процент. Задайте 0, ако не искате да ползвате тази функция <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Включва само <b> за един ден </b> отрицателна промяна на стойността в имейла за отчитане на по-нисък {value} процент. Задайте 0, ако не искате да ползвате тази функция <i>(example: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Включва само <b> за седем дни </b> положителна промяна на стойността в имейла за отчитане на по-висок  {value} процент. Задайте 0, ако не искате да ползвате тази функция <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Включва само <b> за седем дни </b> отрицателна промяна на стойността в имейла за отчитане на по-нисък {value} процент. Задайте 0, ако не искате да ползвате тази функция <i>(example: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Включва само <b> за тридесет дни </b> положителна промяна на стойността в имейла за отчитане на по-висок  {value} процент. Задайте 0, ако не искате да ползвате тази функция <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Включва само <b> за тридесет дни </b> отрицателна промяна на стойността в имейла за отчитане на по-нисък {value} процент. Задайте 0, ако не искате да ползвате тази функция <i>(example: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functional in PRO version)</b> Активирайте тази настройка, ако искате да направите връзката с логото чрез атрибута rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Максимален брой знаци на ред за име на имейла. Промени броя, ако вашия имейл прозорец за съобщения е твърде малък");

DEFINE('_JW_MENU_HISTORY', "История");
DEFINE('_JW_MENU_EMAILS', "Имейли");
DEFINE('_JW_MENU_STATUS', "Статус");
DEFINE('_JW_DESC_BLOCKED',"Тези IP адреси са били блокирани от анти-спам");


DEFINE('_JW_HISTORY_VISITORS',"История за посетителите");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Показани са само %d от последните записи.
                За да промените тази стойности, отидете в Настройки -&gt; История &amp; Изпълнение -&gt; HISTORY_MAX_DB_RECORDS. Бъдете внимателни, тази настройка влияе върху времето за зареждане на данните по-долу.");
DEFINE('_JW_MENU_BUG', "Докладвай за грешки");
DEFINE('_JW_MENU_FEATURE', "Искане за елемент");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Ключови думи");

DEFINE('_JW_BLOCKING_UNBLOCK',"Деблокиране");
DEFINE('_JW_STATS_KEYPHRASE ',"Ключовата дума");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"име на таблицата");
DEFINE('_JW_STATUS_DATABASE_ROWS',"Редове");
DEFINE('_JW_STATUS_DATABASE_DATA',"Данни");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"Общо");

DEFINE('_JW_EMAIL_REPORTS',"Имейл доклади");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Генериран доклад за филтрирани И-мейли от вчера");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Имейл стойност на филтрите");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"Стойност");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"Процент");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-дневна промяна");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-дневна промяна");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-дневна промяна");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch е блокирал %d спамър попадения днес, общо: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Блокирани IP адреси");
DEFINE('_JW_ANTISPAM_SETTINGS',"Анти-спам настройки");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX трафик на актуализациите");


DEFINE('_JW_HISTORY_PREVIOUS',"Предишна");
DEFINE('_JW_HISTORY_NEXT',"Следващата");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Брой колони на държавите");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Брой редове на държавите");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Показване името на страната или не");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Покажи знамената, а след това процента");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET инверсно състояние");
DEFINE('_JW_GOALS_POST_INVERSED', "POST инверсно състояние");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Заглавие-обратно състояние");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Потребителско име обратно състояние");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Идва от обратно състояние");

DEFINE('_JW_STATS_MAP', "Последно посещение Карта");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Моля, въведете <a href='http://www.ipinfodb.com/register.php' target='_blank'> ipinfodb.com </A> за да се появи последното посещение и карта:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"ключ");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Моля, въведете валиден ipinfodb ключ, получен от: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"ЛОШО ИСКАНЕ: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS'," Изпратени области във формата:");
DEFINE('_JW_VISIT_URL_PARAMETERS'," URL параметри:");
DEFINE('_JW_VISIT_ADD_PAGE'," Добави страница като цел");
DEFINE('_JW_VISIT_BLOCK_IP'," Блокиране на този IP адрес");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Добавете тази изпратена форма на променливата като цел");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Добави този URL параметър като цел");

DEFINE('_JW_TREND_EMPTY',"Празен");

DEFINE('_JW_NOT_NUMBER'," ВНИМАНИЕ: Въведената стойност не е число. JoomlaWatch няма да работи нормално!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Това е 15-дневна пробна версия. Дни в ляво: <b>%d</b>. Моля, закупете през този период <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch лиценз за Вашия домейн</a> за тази и предстоящите версии.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Вашата пробна версия е изтекла. Моля закупете JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Лиценза е активиран успешно. Благодаря");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Грешка: лицензния ключ и домейна Ви не съвпадат.</b><br/>Въвели ли сте едно и също име на домейна във формата, коятовиждате по-долу? Моля свържете се с : info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Ако виждате съобщението по-горе като прекалено дълго, Вашия сайт може да бъде грешен. 
                    Отворете елементи/com_joomlawatch/config.php
                    и напишете адреса на сайта Ви, напр.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Забележка: на сайта в браузъра и сайта в конфигурацията: %s и %s не съвпадат.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Задайте сайта, за да: %s и продължете...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Премахване на Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Базата знания");
DEFINE('_JW_ADMINHEADER_FLOW',"Поток");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Графики");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Компоненти");
DEFINE('_JW_ADMINHEADER_REVIEW',"Преглед");
DEFINE('_JW_ADMINHEADER_WRITE',"Добави ");

DEFINE('_JW_FLOW_TRAFFIC',"Поток на трафика ");
DEFINE('_JW_FLOW_SELECT_PAGE',"Изберете страница:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root изходящи броя връзки:");
DEFINE('_JW_FLOW_NESTING',"Ниво на разполагане:");
DEFINE('_JW_FLOW_SCALE',"Скала:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Безплатна версия");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Благодаря Ви много за дарението!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Регистрационият ключ за Вашия домейн %s е: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Сега можете да премахнете или скриете JoomlaWatch логото в интерфейса от настройките");


DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Компонент");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Общо:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Размер");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Обнови всичко");

DEFINE('_JW_SIZEDATABASE_TABLE',"Таблица");
DEFINE('_JW_SIZEDATABASE_SIZE',"Размер");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-дневна промяна");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-дневна промяна");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-дневна промяна");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"няма данни");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Общо:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Обнови всичко");
DEFINE('_JW_SIZEMODULES_TOTAL',"Общо:");
DEFINE('_JW_SIZEMODULES_MODULE',"Модул");
DEFINE('_JW_SIZEMODULES_SIZE',"Размер");

DEFINE('_JW_SIZES_FILES',"Файлове &amp; Директории");
DEFINE('_JW_SIZES_BYTES',"байта");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Обнови");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");


DEFINE('_JW_DESC_IPINFODB_KEY',"Карта на последно посещение ipinfodb.com от: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");

/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");
?>