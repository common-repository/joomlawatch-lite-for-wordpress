<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistika");
DEFINE('_JW_MENU_GOALS', "Cíle");
DEFINE('_JW_MENU_SETTINGS', "Nastavení");
DEFINE('_JW_MENU_CREDITS', "Poděkování");
DEFINE('_JW_MENU_FAQ', "Časté otázky");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentace");
DEFINE('_JW_MENU_LICENSE', "Licence");
DEFINE('_JW_MENU_DONATORS', "Podporovatelé");
DEFINE('_JW_MENU_SUPPORT', "Podpořte JoomlaWatch a reklamy se Vám nebudou zobrazovat.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Poslední návštevníci");
DEFINE('_JW_VISITS_BOTS', "Roboti");
DEFINE('_JW_VISITS_CAME_FROM', "Přišel z");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Váš JoomlaWach modul není publikovaný. Žádná statistiky se proto nezaznamenávají. Jděte do sekcee modulů a nastavte pro modul JoomlaWatch Agent - publikovat na všech stránkách");
DEFINE('_JW_VISITS_PANE_LOADING', "Načítám...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Statistiky návštev pro týden");
DEFINE('_JW_STATS_WEEK', "Týden");
DEFINE('_JW_STATS_THIS_WEEK', "tento týden");
DEFINE('_JW_STATS_UNIQUE', "jedinečné");
DEFINE('_JW_STATS_LOADS', "načítaní");
DEFINE('_JW_STATS_HITS', "hits");
DEFINE('_JW_STATS_TODAY', "dnes");
DEFINE('_JW_STATS_FOR', "pro");
DEFINE('_JW_STATS_ALL_TIME', "Celé období");
DEFINE('_JW_STATS_EXPAND', "rozbalit");
DEFINE('_JW_STATS_COLLAPSE', "sbalit");
DEFINE('_JW_STATS_URI', "Stránky");
DEFINE('_JW_STATS_COUNTRY', "Země");
DEFINE('_JW_STATS_USERS', "Uživatelé");
DEFINE('_JW_STATS_REFERERS', "Odkazovatelé");
DEFINE('_JW_STATS_IP', "IP adresy");
DEFINE('_JW_STATS_BROWSER', "Prohlížeče");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "Klíčová slova");
DEFINE('_JW_STATS_GOALS', "Cíle");
DEFINE('_JW_STATS_TOTAL', "Celkově");
DEFINE('_JW_STATS_DAILY', "Denní");
DEFINE('_JW_STATS_DAILY_TITLE', "Denní statistiky");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Celkové statistiky");
DEFINE('_JW_STATS_LOADING', "načítám...");
DEFINE('_JW_STATS_LOADING_WAIT', "načítám... prosím čekejte");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blokovaní IP adres");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Vložte manuálně IP");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Vložte IP adresu, kterou chcete zablokovat. (např. 217.242.11.54 nebo 217.* a nebo 217.242.* pro zablokování rozsahu hvězdičkou)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Skutečně zapnout blokování IP");
DEFINE('_JW_STATS_PANE_LOADING', "Načítám statistiky...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Nastavení");
DEFINE('_JW_SETTINGS_DEFAULT', "Standardně");
DEFINE('_JW_SETTINGS_SAVE', "Uložit");
DEFINE('_JW_SETTINGS_APPEARANCE', "Vzhled");
DEFINE('_JW_SETTINGS_FRONTEND', "Vzhled na stránce");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Historie a Výkonnost");
DEFINE('_JW_SETTINGS_ADVANCED', "Rozšířené");
DEFINE('_JW_SETTINGS_IGNORE', "Ignorování");
DEFINE('_JW_SETTINGS_BLOCKING', "Blokovaní");
DEFINE('_JW_SETTINGS_EXPERT', "Expert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Skutečně chcete vymazat všechny údaje?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Vymaž všetky údaje");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Vymaž všetky statistické a návštěvnické údaje");
DEFINE('_JW_SETTINGS_LANGUAGE', "Jazyk");
DEFINE('_JW_SETTINGS_SAVED', "Nastavení bylo uloženo");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Přidejte vaši IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "do seznamu.");

# Other / mostly general
DEFINE('_JW_TITLE', "AJAX monitor pro Joomla CMS");
DEFINE('_JW_BACK', "Zpět");
DEFINE('_JW_ACCESS_DENIED', "Nemáte žádné práva na tento obsah");
DEFINE('_JW_LICENSE_AGREE', "Souhlasím s podmínkami");
DEFINE('_JW_LICENSE_CONTINUE', "Pokračovat");
DEFINE('_JW_SUCCESS', "Operace proběhla úspěšně");
DEFINE('_JW_RESET_SUCCESS', "Všechny statistické údaje a údaje o návštevnících byly vymazány");
DEFINE('_JW_RESET_ERROR', "Údaje neboly vymazány, něco se nezdařilo");
DEFINE('_JW_CREDITS_TITLE', "Poděkování");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Denní a týdenní statistiky pro údaj:");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX přístup odmítnut: Prosím, prohlížejte tyto statistiky z domény, kterou jste specifikovali v configuration.php systému joomla - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Možná jste pouze zapomněli zadat www. před názvem vaší domény v prohlížeči. Javascript zkouší získat obsah ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "z");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "co ho nutí si myslet, že je to jiná doména.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Získejte nejnovější kód tohoto rozšíření z");
DEFINE('_JW_HEADER_CAST_YOUR', "Zašlete svůj");
DEFINE('_JW_HEADER_VOTE', "Hlas");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Klikněte pro otevření tooltip okna");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Přejeďte myší pro otevření tooltip okna");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "včerejší přírůstek");
DEFINE('_JW_TOOLTIP_HELP', "Otevře online externí nápovědu pro");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Zavřít toto okno");
DEFINE('_JW_TOOLTIP_PRINT', "Tisk");

# Goals
DEFINE('_JW_GOALS_INSERT', "Přidat nový cíl");
DEFINE('_JW_GOALS_UPDATE', "Uprav cíl číslo");
DEFINE('_JW_GOALS_ACTION', "Akce");
DEFINE('_JW_GOALS_TITLE', "Nový cíl");
DEFINE('_JW_GOALS_NEW', "Nový cíl");
DEFINE('_JW_GOALS_RELOAD', "Obnovit");
DEFINE('_JW_GOALS_ADVANCED', "Rozšířené");
DEFINE('_JW_GOALS_NAME', "Jméno");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "URI podmínka");
DEFINE('_JW_GOALS_GET_VAR', "GET proměnná");
DEFINE('_JW_GOALS_GET_CONDITION', "GET podmínka");
DEFINE('_JW_GOALS_POST_VAR', "POST proměnná");
DEFINE('_JW_GOALS_POST_CONDITION', "POST podmínka");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Title podmínka");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Username podmínka");
DEFINE('_JW_GOALS_IP_CONDITION', "IP podmínka");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "'Přišel z adresy...' podmínka");
DEFINE('_JW_GOALS_BLOCK', "Blokovat");
DEFINE('_JW_GOALS_REDIRECT', "Přesměrovat na URL");
DEFINE('_JW_GOALS_HITS', "Hits");
DEFINE('_JW_GOALS_ENABLED', "Povolené");
DEFINE('_JW_GOALS_EDIT', "Upravit");
DEFINE('_JW_GOALS_DELETE', "Vymazat");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Ztratíte všechny nynější statistická data pro tento cíl. Chcete opravdu vymazat cíl číslo ");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Země");
DEFINE('_JW_FRONTEND_VISITORS', "Návštěvníci");
DEFINE('_JW_FRONTEND_TODAY', "Dnes");
DEFINE('_JW_FRONTEND_YESTERDAY', "Včera");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Tento týden");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Minulý týden");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Tento měsíc");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Minulý měsíc");
DEFINE('_JW_FRONTEND_TOTAL', "Celkově");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch je v debug módu. Touto cestou můžete zjistit příčiny chyb. Pro vypnutí, změňte prosím hodnotu JOOMLAWATCH_DEBUG v /components/com_joomlawatch/config.php z 1 na 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Maximální počet řádků pro údaje po rozbalení ve statistice");
DEFINE('_JW_DESC_STATS_IP_HITS', "Všechny IP adresy, které mají méně hitů předchozí den než je nastavená hodnota, budou vymazané z historie IP adres.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Všechny URL, které mají méně hitů předchozí den než je nastavená hodnota, budou vymazané z historie URL.");
DEFINE('_JW_DESC_IGNORE_IP', "Ignoruj tyto IP adresy ve statistice. Oddělte novým řádkem. Můžete použít hvězdičky. <br/>Např. 192.* bude ignorovat 192.168.51.31, 192.168.16.2, atd...");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Doba obnovování návštevníků vlevém panelu v milisekundách, standardně 2000, buďte opatrní s tímto nastavením. Pro projevení nastavení, znovu načtěte administrační rozhraní JoomlaWatch-u.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Doba obnovování statistik vpravém panelu v milisekundách, standardne 2000, buďte opatrní s tímto nastavením. Pro projevení nastavení, znovu načtěte administrační rozhraní JoomlaWatch-u.");
DEFINE('_JW_DESC_MAXID_BOTS', "Kolik záznamů o robotech uchovávat v databázi.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Kolik záznamů o návštevnících uchovávat v databázi.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Kolik záznamů robotů uvidíte vlevém panelu v administračním rozhraní.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Kolik záznamů reálných návštevníků uvidíte vlevém panelu v administračním rozhraní.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maximum znaků, které budou zobrazeny pro dlouhé titulky a URI adresy");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Maximum znaků, které budou zobrazeny pro dlouhé titulky vpravém statistickém panelu");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Počet dní, za které uchovávat celkovou historii statistik v databázi. 0 = nekonečno.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Pokud jste v jiném časovém pásmu, než je váš server na kterém hostujete stránky. (Zadejte kladné nebo záporné číslo pro rozdíl časového pásma)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Posun v rámci týdne, timestamp/(3600*24*7) vrací číslo týdne od 1.1.1970, tento posun je korekcí, aby týden začínal pondělím. V normálních případech není potřebné měnit.");
DEFINE('_JW_DESC_DAY_OFFSET', "Posun v rámci dne, timestamp/(3600*24) vrací číslo dne od 1.1.1970, tento posun je korekcí, aby den začínal o 00:00. V normálních případech není potřebné měnit.");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Pro nahrazení loga JoomlaWatch neviditelným logem na stránkách");
DEFINE('_JW_DESC_IP_STATS', "Používat i IP adresy ve statistikách. V některých zemích se IP adresa považuje za osobní údaj. Používejte na vlastní riziko.");
DEFINE('_JW_DESC_HIDE_ADS', "This setting hides the ads in the backend, if they really annoy you. By keeping them, you support the further development of this tool. Thank you");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Nastavte na nezaškrtnuté, pokud chcete zobrazovat okna grafů a map po přejetí kurzoru nad danými ikonkami, namísto kliknutí.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Standardně je toto nastavení 'REDIRECT_URL', pokud používate url rewriting, můžete nastavit i na 'SCRIPT_URL' pokud se ve vašich statistikách zobrazuje jen index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Zpráva, která je zobrazena zablokovaným používatelům, a nebo další informace z jakého důvodu jste dané uživatele zablokovali.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Šířka tooltip okna");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Výška tooltip okna");
DEFINE('_JW_DESC_TOOLTIP_URL', "Můžete sem dát libovolnou adresu, pro vizualizaci IP adresy návštevníka. {ip} bude nahrazené aktuální IP adresou uživatele. Příklad: http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Napište, které URI chcete ignorovat ve statistikách. Můžete zde použít (* a ?). Např. : /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Specifikujte jméno cíle. Toto jméno následně uvidíte ve statistikách.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "To, co se nachází hned za adresou vaší domény. Pro http://www.codegravity.com/projects/ je URI: /projects/ (Příklad: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET proměnná je obyčejně to, co vidíte v URL obyčejně za znakem ? a nebo &amp; znakem. Např: http://www.codegravity.com/index.php?<u>jméno</u>=peter&amp;<u>příjmení</u>=smith. Můžete též použít <u>*</u> v tomto políčku pro procházení všech get proměnných. (Příklad: <b>m*no</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Zde můžete specifikovat čemu se má rovnat proměnná z předcházejícího pole. (Příklad: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Celkem podobně zjišťujeme hodnoty zadané do formulářů. Tedy, pokud máte na stránce formulář, který má vstupní pole &lt;input type='text' name='<u>zkušenosti</u>' /&gt;. (Příklad: <b>zk*enosti</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Hodnota, které se má rovnat proměnná z předcházejího POST pole. Např. Chceme zjistit, jaký uživatel do formuláře zadal v poli zkušenosti hodnotu java. (Příklad: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Titulek stránky, který se má shodovat. (Příklad: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Jméno přihlášeného uživatele, na kterého se cíl vztahuje. (Příklad: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP adresa, která pochází z adresy: (Příklad: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL adresa, z které přišel daný návštevník. (Příklad: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Pokud jsou splněné výše uvedené podmínky, můžete uživatele přesměrovat na danou vámi zvolenou adresu. Má vyšší prioritu než 'blokovaní': (Příklad: <b>http://www.codegravity.com/jdi-pryc.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Kolik znaků maximálně ukazovat v tabulce cílů pro dlouhé názvy");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Zpětný odkaz na codegravity.com, můžete toto nastavení změnit, ale budeme vděční, pokud ho ponecháte.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Zobraz celkové statistiky v modulu na stránce. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Pokud chcete prohodit pořadí Návštěvníci/Země v modulu na stránce, odškrtněte toto a statistika Návštěvníci se bude zobrazovat jako první, za ní Země.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Počet zemí, které si přejete ukazovat v modulu na stránkách");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Zobraz země v modulu na stránkách. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Čas v sekundách, jak často se mají obnovovat statistiky zemí v modulu na stránkách");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Čas v sekundách, jak často se mají obnovovat statistiky návštěvníků v modulu na stránkách");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Zobraz návštevníky na stránce pro: dnes. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Zobraz návštevníky na stránce pro: včera. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Zobraz návštevníky na stránce pro: tento týden. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Zobraz návštevníky na stránce pro: minulý týden. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Zobraz návštevníky na stránce pro: tento měsíc. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Zobraz návštevníky na stránce pro: minulý měsíc. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Zobraz návštevníky celkově od instalace JoomlaWatch. Pokud nastavení změníte, musíte počkat čas uvedený v CACHE_FRONTEND_ , aby se změny projevily");
DEFINE('_JW_DESC_LANGUAGE', "Jazykový soubor, který se má použít. Jazykové soubory jsou umístěné v /components/com_joomlawatch/lang/. Pokud chcete přidat nový jazyk, nejdříve se přesvěčte, zda se již nenachází na stránkách tohoto projektu. Pokud tam není, zkopírujte standardní english.php napríklad na mujjazyk.php a umístěte ho do daného adresáre. Následně přeložte všechny názvy vpravo. Nejlepší je, pokud použijete kódovaní UTF-8");
DEFINE('_JW_DESC_GOALS', "Cíle vám umožňují zadat speciální parametry. Pokud tyto parametry souhlasí, počítadlo daného cíle se zvýší. Tímto způsobem můžete monitorovat, zda návštěvník navštívil specifickou URI, poslal specifickou hodnotu ve formuláři, má specifické uživatelské jméno, anebo přišel z některé adresy. Můžete takového návštevníka zablokovat, anebo přesměrovat na speciální URL adresu.");
DEFINE('_JW_DESC_GOALS_INSERT', "Ve všech polích, mimo jména, můžete používat znaky * a ?. Například: ?ear (obsáhne: near, tear, ..),  p*r (obsáhne: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Nastavte na 1, pokud si přejete, aby byl návštěvník, který vyhovuje podmínkám, blokovaný. Nebude vidět zbytek obsahu stránek, pouze zprávu o jeho blokovaní - bez přesměrovaní, a jeho IP adresa bude přidaná do seznamu blokovaných adres ve statistice (Příklad: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Podmínka země");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Dvojpísmenný kód země (Např.: <b>CZ</b>)");
DEFINE('_JW_STATS_INTERNAL',"Pohyb na stránce");
DEFINE('_JW_STATS_FROM',"Z");
DEFINE('_JW_STATS_TO',"Do");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Přidej k cílům");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Přidej cíl pro tuto zemi");
DEFINE('_JW_MENU_REPORT_BUG',"Ohlas chybu anebo návrh");
DEFINE('_JW_GOALS_COUNTRY',"Země");

/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Pokud chcete, aby se názvy zemí zobrazovaly na stránkách se všemi velkými písmeny (Např.: GERMANY, UNITED KINGDOM namísto Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Čas v sekundách, jak často se mají obnovovat statistiky uživatelů v modulu na stránkách");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Počátečná hodnota 'Celkově:' na stránkách. Užitečné, pokud jste migrovali z jiného statistického nástroje. (Např.: 20000). Nastavte zpět na 0 pokud nechcete používat tuto vlastnost.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignorujte uživatele z tohoto textbox-u. Uživatelské jméno na řádek. (Např.: myself {nový řádek} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Nejaktívnější uživatelé za dnešek z celkového počtu");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Povolit blokovaní na základě listu spam slov zobrazeného níže?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Nejpoužívanější spamová slova používaná spamovými roboty. Můžete použit * a ?. (Např.: ph?rmac*). Pokud nastavení výše je povolené, JoomlaWatch bude zjišťovat, zda útočník odeslal formulář (HTTP POST požadavek) na vaší stránce s něktorým z těchto slov. (Vztahuje se jen na Joomla stránky - fórum, komentáře, a je to celkem efektívní způsob eliminování spamových robotů, kteří zkoušejí odeslat každý možný formulář)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Link na profil uživatele ve frontend-u. Toto nastavevení umožňuje specifikovat URL, která se otevře při kliknutí na jméno uživatele. Musí obsahovat řetězec {user}, který bude nahrazovat aktuální uživatelské jméno. (Např. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Keyphrases");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum values in history tab (Example: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In visits show only last page visited, not all");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In visits hide repetitive sitename in visited page title");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximum nuber of visitors to keep in database for Visit History. Be careful with this setting, if you have high traffic, it can grow really fast. Always check how much data the history table contains in Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Keep Database Tables on uninstall. Check this option before uninstall if you are doing an upgrade and want to keep your data.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "You'll receive nightly emails with reports for previous day, which you can read in the morning");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Email address to which you'll receive these reports");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Only include rows in email reports where percentage is higher than {value}. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Only include <b>positive one day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Only include <b>negative one day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Only include <b>positive seven day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Only include <b>negative seven day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Only include <b>positive thirty day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Only include <b>negative thirty day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functional in PRO version)</b> Enable this setting if you want to make the logo link rendered with attribute rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum characters of email row name. Change this if your email client message window is too small");

DEFINE('_JW_MENU_HISTORY', "History");
DEFINE('_JW_MENU_EMAILS', "Emails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"These IPs were blocked by anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Visitors History");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Showing only %d last records.
                To change this value, go to Settings -&gt; History &amp; Performance -&gt; HISTORY_MAX_DB_RECORDS . Be careful, this setting affects load times of the data below.  ");
DEFINE('_JW_MENU_BUG', "Report Bug");
DEFINE('_JW_MENU_FEATURE', "Request Feature");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Keywords");

DEFINE('_JW_BLOCKING_UNBLOCK',"unblock");
DEFINE('_JW_STATS_KEYPHRASE ',"Keyphrase");
DEFINE('_JW_STATUS_DATABASE',"Database status");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"table name");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rows");
DEFINE('_JW_STATUS_DATABASE_DATA',"data");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"total");

DEFINE('_JW_EMAIL_REPORTS',"Email Reports");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generated filtered email report from yesterday");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Email Value Filters");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"value");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-day change");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-day change");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-day change");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch has blocked %d spammer hits today, total: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blocked IP Adresses");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Settings");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX updates traffic");


DEFINE('_JW_HISTORY_PREVIOUS',"previous");
DEFINE('_JW_HISTORY_NEXT',"next");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Number of columns of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Number of rows of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Display country names or not");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Display flags first, then percents");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET inversed condition");
DEFINE('_JW_GOALS_POST_INVERSED', "POST inversed condition");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Title inversed condition");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Username inversed condition");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Came from inversed condition");

DEFINE('_JW_STATS_MAP', "Last Visit Map");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Please enter <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> key to display last visit map:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"store key");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Please enter valid ipinfodb key you obtained from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Submitted form fields:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameters:");
DEFINE('_JW_VISIT_ADD_PAGE'," Add page as goal");
DEFINE('_JW_VISIT_BLOCK_IP'," Block this IP Address");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Add this submitted form variable as goal");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Add this URL parameter as goal");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," WARNING: The value you entered is not a number. JoomlaWatch will not work properly!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; This is a 15-day Evaluation Version. Days Left: <b>%d</b>. Please purchase the lifetime <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Your trial version has expired. Please purchase JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"License activated successfully. Thank you");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: the license key and your domain don't match.</b><br/>Did you enter the same domain name into activation form as one you see below? Please contact: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"If you are seeing the message above for too long, your live site may be wrong.
                    Open the components/com_joomlawatch/config.php
                    uncomment, and set your actual live site. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Warning: site in your browser and live site in configuration: %s and %s don't match.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Set live site to: %s and continue...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Remove Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flow");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphs");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Components");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Write a ");

DEFINE('_JW_FLOW_TRAFFIC',"Traffic Flow");
DEFINE('_JW_FLOW_SELECT_PAGE',"Select page:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root outgoing links count:");
DEFINE('_JW_FLOW_NESTING',"Nesting level:");
DEFINE('_JW_FLOW_SCALE',"Scale:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Ad-free version");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Thank you very much for your donation!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registration key for your domain %s is: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Now you can remove backlink or hide JoomlaWatch logo in frontend from Settings ");


DEFINE('_JW_SIZES_LAST_CHECK',"Last check was performed on:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Size of component/module in /administrator directory");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Component");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Size");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Refresh All");

DEFINE('_JW_SIZEDATABASE_TABLE',"Table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Size");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Day Change");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Day Change");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Day Change");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"no data");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Refresh All");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Module");
DEFINE('_JW_SIZEMODULES_SIZE',"Size");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Refresh");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Last visit map ipinfodb.com key from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");

/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");

?>