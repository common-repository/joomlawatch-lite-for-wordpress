<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistieken");
DEFINE('_JW_MENU_GOALS', "Doelen");
DEFINE('_JW_MENU_SETTINGS', "Instellingen");
DEFINE('_JW_MENU_CREDITS', "Credits");
DEFINE('_JW_MENU_FAQ', "FAQ");
DEFINE('_JW_MENU_DOCUMENTATION', "Documentatie");
DEFINE('_JW_MENU_LICENSE', "Reclame vrije licentie");
DEFINE('_JW_MENU_DONATORS', "Donateuren");
DEFINE('_JW_MENU_SUPPORT', "Steun JoomlaWatch en krijg een administratie zonder reclame.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Nieuwste Bezoekers");
DEFINE('_JW_VISITS_BOTS', "Bots");
DEFINE('_JW_VISITS_CAME_FROM', "Herkomst");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Uw JoomlaWatch module is niet gepubliceerd! Er worden geen nieuwe statistieken geregistreerd. Om het te publiceren, ga naar de module sectie en activeer de module op alle paginas");
DEFINE('_JW_VISITS_PANE_LOADING', "Laden bezoekers...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Bezoekers statistieken voor week");
DEFINE('_JW_STATS_WEEK', "Week");
DEFINE('_JW_STATS_THIS_WEEK', "deze week");
DEFINE('_JW_STATS_UNIQUE', "uniek");
DEFINE('_JW_STATS_LOADS', "geladen");
DEFINE('_JW_STATS_HITS', "hits");
DEFINE('_JW_STATS_TODAY', "vandaag");
DEFINE('_JW_STATS_FOR', "voor");
DEFINE('_JW_STATS_ALL_TIME', "Totaal");
DEFINE('_JW_STATS_EXPAND', "uitvouwen");
DEFINE('_JW_STATS_COLLAPSE', "dichtvouwen");
DEFINE('_JW_STATS_URI', "Paginas");
DEFINE('_JW_STATS_COUNTRY', "Landen");
DEFINE('_JW_STATS_USERS', "Gebruikers");
DEFINE('_JW_STATS_REFERERS', "Verwijzers");
DEFINE('_JW_STATS_IP', "IPs");
DEFINE('_JW_STATS_BROWSER', "Browsers");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "Kernwoorden");
DEFINE('_JW_STATS_GOALS', "Doelen");
DEFINE('_JW_STATS_TOTAL', "Totaal");
DEFINE('_JW_STATS_DAILY', "Dagelijks");
DEFINE('_JW_STATS_DAILY_TITLE', "Dagelijkse statistieken");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Totale statistieken");
DEFINE('_JW_STATS_LOADING', "laden...");
DEFINE('_JW_STATS_LOADING_WAIT', "laden... een ogenblik aub");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP blokkering");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "IP met de hand toevoegen");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Geef het IP adres op dat geblokkeerd moet worden. (bv. 217.242.11.54 of 217.* of 217.242.* om alle IPs die hiermee beginnen te blokkeren)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Wilt U werkelijk de blokkering wijzigen van ");
DEFINE('_JW_STATS_PANE_LOADING', "Statistieken laden...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Instellingen");
DEFINE('_JW_SETTINGS_DEFAULT', "Standaard");
DEFINE('_JW_SETTINGS_SAVE', "Opslaan");
DEFINE('_JW_SETTINGS_APPEARANCE', "Uiterlijk");
DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Geschiedenis & Prestaties");
DEFINE('_JW_SETTINGS_ADVANCED', "Geavanceerd");
DEFINE('_JW_SETTINGS_IGNORE', "Negeren");
DEFINE('_JW_SETTINGS_BLOCKING', "Geblokkeerd");
DEFINE('_JW_SETTINGS_EXPERT', "Expert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Wilt U werkelijk alle statistieken & bezoeker data terugzetten?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Herstellen");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Alle statistieken & bezoeker data terugzetten");
DEFINE('_JW_SETTINGS_LANGUAGE', "Taal");
DEFINE('_JW_SETTINGS_SAVED', "Instellingen zijn opgeslagen");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Voeg Uw IP toe");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "aan de lijst.");

# Other / mostly general
DEFINE('_JW_TITLE', "Een realtime AJAX Joomla Monitor");
DEFINE('_JW_BACK', "Terug");
DEFINE('_JW_ACCESS_DENIED', "U heeft geen toestemming deze gegevens te bekijken !");
DEFINE('_JW_LICENSE_AGREE', "Ik accepteer de bovenstaande voorwaarden en condities");
DEFINE('_JW_LICENSE_CONTINUE', "Verder gaan");
DEFINE('_JW_SUCCESS', "Operatie succesvol");
DEFINE('_JW_RESET_SUCCESS', "Alle statistieken en bezoeker data zij succesvol verwijderd");
DEFINE('_JW_RESET_ERROR', "Het verwijderen van de data is niet gelukt, er is iets mis gegaan");
DEFINE('_JW_CREDITS_TITLE', "Credits");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Dagelijkse en wekelijkse statistieken");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX permissie verboden: Bekijk deze statistieken van het domein dat U heeft gespecificeerd in de configuration.php van joomla - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Misschien ben U vergeten www. voor uw domeinnaam te zetten. Het javascript probeert toegang te krijgen tot ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "van");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "wat ervoor zorgt dat het denkt dat het een ander domein is.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Kijk voor de nieuwste extensies op:");
DEFINE('_JW_HEADER_CAST_YOUR', "Geef je");
DEFINE('_JW_HEADER_VOTE', "Stem");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Klik om de tooltip te zien");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Beweeg hier je muis over om de tootip te zien");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "Stijging van gisteren");
DEFINE('_JW_TOOLTIP_HELP', "Open externe online help voor");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Dit venster sluiten");
DEFINE('_JW_TOOLTIP_PRINT', "Print");

# Goals
DEFINE('_JW_GOALS_INSERT', "Doel toevoegen");
DEFINE('_JW_GOALS_UPDATE', "Bijwerken van doel nr.");
DEFINE('_JW_GOALS_ACTION', "Actie");
DEFINE('_JW_GOALS_TITLE', "Nieuw doel");
DEFINE('_JW_GOALS_NEW', "Nieuw doel");
DEFINE('_JW_GOALS_RELOAD', "Herladen");
DEFINE('_JW_GOALS_ADVANCED', "Geavanceerd");
DEFINE('_JW_GOALS_NAME', "Naam");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "URI voorwaarden");
DEFINE('_JW_GOALS_GET_VAR', "GET variabele");
DEFINE('_JW_GOALS_GET_CONDITION', "GET voorwaarde");
DEFINE('_JW_GOALS_POST_VAR', "POST variabele");
DEFINE('_JW_GOALS_POST_CONDITION', "POST voorwaarde");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Titel voorwaarde");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Username voorwaarde");
DEFINE('_JW_GOALS_IP_CONDITION', "IP voorwaarde");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Herkomst voorwaarde");
DEFINE('_JW_GOALS_BLOCK', "Blok");
DEFINE('_JW_GOALS_REDIRECT', "Verwijzen naar URL");
DEFINE('_JW_GOALS_HITS', "Hits");
DEFINE('_JW_GOALS_ENABLED', "Geactiveerd");
DEFINE('_JW_GOALS_EDIT', "Wijzigen");
DEFINE('_JW_GOALS_DELETE', "Verwijderen");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "U zal alle recente statistieken voor dit doel verliezen. Wilt U werkelijk het doel verwijderen met nr.");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Landen");
DEFINE('_JW_FRONTEND_VISITORS', "Bezoekers");
DEFINE('_JW_FRONTEND_TODAY', "Vandaag");
DEFINE('_JW_FRONTEND_YESTERDAY', "Gisteren");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Deze Week");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Vorige Week");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Deze Maand");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Vorige Maand");
DEFINE('_JW_FRONTEND_TOTAL', "Totaal");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch is in debug mode. Op deze manier kunt U fouten ontdekken. Om deze mode te deactiveren verander dan de waarde van JOOMLAWATCH_DEBUG in /components/com_joomlawatch/config.php van 1 naar 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Maximaal aantal rijen wanneer de statistieken in uitgeklapte vorm getoond worden.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Alle IP adressen, die minder hits hebben dan deze waarde, worden uit de IP geschiedenis verwijderd.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Alle URLs, die minder hits hebben dan deze waarde, worden uit de IP geschiedenis verwijderd.");
DEFINE('_JW_DESC_IGNORE_IP', "Bepaalde IP adressen van de statistiek uitsluiten. Gebruik voor elk adres op een nieuwe regel. <br/>bv. 217.242.11.54 of 217.* of 217.242.* om alle IPs die hiermee beginnen te blokkeren.");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Bezoeker verversings tijd in milliseconden, standard is 2000, wees hier voorzichtig mee. Hierna de JoomlaWatch administratie herladen.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Statistiek verversings tijd in milliseconden, standard is 4000, wees hier voorzichtig mee. Hierna de JoomlaWatch administratie herladen.");
DEFINE('_JW_DESC_MAXID_BOTS', "Hoeveel bezoeken van bots in de database bewaard moeten worden.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Hoeveel werkelijke bezoeken er in de database bewaard moeten worden.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Hoeveel bots er getoond worden aan de administratie kant.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Hoeveel werkelijke bezoekers er getoond worden aan de administratie kant.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maximaal aantal letters die bij lange titels en URIs getoond worden.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Maximaal aantal letters die in het rechter statistiek paneel worden getoond.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Aantal dagen dat de statistieken in de database bewaard moeten worden, 0 = oneindig.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Wanneer U zich in een andere tijdzone bevindt dan Uw server. (positieve of negatieve waarde in uren)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Weekverschuiving, het tijdstip/(3600*24*7) geeft het week nummer vanaf 1.1.1970, deze verschuiving is een correctie om de week op mandag te beginnen");
DEFINE('_JW_DESC_DAY_OFFSET', "Dagverschuiving, het tijdstip/(3600*24) geeft het dag nummer vanaf 1.1.1970, deze verschuiving is een correctie om de dag om 00:00 te beginnen");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Om een transparant icoon van 1x1px op de voorpagina te gebruiken");
DEFINE('_JW_DESC_IP_STATS', "Om de IP adresstatistieken te activeren. In sommige landen is het verboden om IP adressen voor langere tijd te bewaren. Gebruik op eigen risico!");
DEFINE('_JW_DESC_HIDE_ADS', "Deze instelling verbergt de reclame in de administratie, mochten ze irritant zijn. Door ze te laten staan helpt U de ontwikkeling van dit component, Dank U wel.");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Wanneer U de tooltip wil laten zien bij mouse-over, ipv bij mouse klik, vinkje weghalen.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Standard is 'REDIRECT_URL', dat is de standaard wanneer U URL-Rewriting gebruikt, het kan op 'SCRIPT_URL' gezet worden, wanneer alleen de index.php bewaakt wordt");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Het bericht dat de geblokkeerde bezoeker ziet of meer informatie over de reden waarom de bezoeker wordt geblokkeerd.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Tooltip breedte");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Tooltip hoogte");
DEFINE('_JW_DESC_TOOLTIP_URL', "U kan hier elke URL invullen als voorbeeld voor de bezoeker. De {ip} wordt door de IP van de bezoeker vervangen. Bijvoorbeeld: http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "U kunt hier elke URI in voeren die door de statistieken genegeerd moet worden. U kan vervangingstekens gebruiken (* en ?). Bv.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Specificeer de naam van een doel hier. Deze naam vind je terug in de statistieken.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Alles dat achter Uw domeinnaam komt. Voor http://www.codegravity.com/projects/ de URI is: /projects/ (Voorbeeld: <b>/projects*</b>");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET variabele is een variabele die U meestal in de URL ziet na een ? or & sign. Bv. http://www.codegravity.com/index.php?<u>name</u>=peter&<u>surname</u>=smith. U kan ook <u>*</u> in dit veld gebruiken om alle waarden te scannen. (Voorbeeld: <b>n*me</b>");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Vul hier de waarde in die met de de waarde van het vorige veld (GET-varialbele) overeen moet komen. (Voorbeeld: <b>p?t*r</b> ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Ongeveer hetzelfde, maar hier vergelijken we de waarde met die van formulieren. Dus wanneer U een formulier op de website heeft staan, en die heeft een waarde met bv <input type='text' name='<u>experiences</u>' />, dan kan U het volgende gebruiken: voorbeeld: <b>exper*ces</b>");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Vul hier de waarde in die met de de waarde van het vorige veld (POST-varialbele) overeen moet komen. Bv. we willen weten of de gebruiker java ervaring heeft. (Voorbeeld: <b>*java*</b>");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Een titel van een pagina die overeen moet komen. (Voorbeeld: <b>*freelance programmers*</b>");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Een naam van een ingelogde gebruiker. (Voorbeeld: <b>psmith*</b>");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP waar een gebruiker vandaan komt: (Voorbeeld: <b>201.9?.*.*</b>");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "Een URL waar de gebruiker vandaan komt. (Voorbeeld: <b>*www.google.*</b>");
DEFINE('_JW_DESC_GOALS_REDIRECT', "De gebruiker wordt door gestuurd naar een door U gespecificeerde URL. Heeft een hogere prioriteit dan 'blokkeren': (Voorbeeld: <b>http://www.codegravity.com/goaway.html</b>");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Maximaal aantal letters die getoond worden in de doelen tabel");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Backlink naar codegravity.com, U kunt deze depubliceren, maar we stellen het op prijs als U het laat staan. Dank U wel");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Laat het totaal aantal landen zien in de frontend module. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Wanneer U de volgorde van Bezoekers/Landen wil wijzigen. Zonder vinkje staan de Bezoekers bovenaan.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Aantal landen dat te zien is in de frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Laat het bezoekers zien in de frontend module. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Tijd in seconden om de cache op te halen voor het totaal aantal landen in de frontend");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Tijd in seconden om de cache op te halen voor het totaal aantal bezoekers in de frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Laat de boezoekrs in de frontend zien voor: vandaag. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Laat de boezoekrs in de frontend zien voor: gisteren. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Laat de boezoekrs in de frontend zien voor: deze week. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Laat de boezoekrs in de frontend zien voor: vorige week. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Laat de boezoekrs in de frontend zien voor: deze maand. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Laat de boezoekrs in de frontend zien voor: vorige maand. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Laat het totaal aantal bezoekers zien na de installatie van JoomlaWatch. Deze instelling is effectief nadat de tijd is ingesteld in de CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "Te gebruiken taal bestand. Plaats deze in /components/com_joomlawatch/lang/. Wanneer U een compleet nieuw taal bestand wil maken, check dan eerst de homepage van het project, en indien het taal bestand ook daar niet aanwezig is, kopieer dan de standaard english.php naar bv. dutch.php en plaats deze dan in deze directory. Vertaal daarna alle waarden aan de rechterkant.");
DEFINE('_JW_DESC_GOALS', "Doelen laten U toe speciale parameters te specificeren. Wanneer deze parameters overeen komen wordt de doelen teller verhoogd. Op deze manier kan U in de gaten houdenof de bezoeker een specifieke URL heeft bezocht, een specifieke waarde heeft gepost, een specifieke gebruikersnaam heeft of vanaf een specifiek adres komt. U kan ook zulke bezoekers blokkeren of door sturen naar een andere URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "U kan in alle velden, behalve de naam, de vervangingstekens * en ? gebruiken. Bij voorbeeld: ?ear (zal overeen komen met: near, tear, ..), p*r (zal overeen komen met: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Stel in op 1, als U de bezoeker wil blokkeren. Hij zal de verdere inhoud niet zien, alleen het bericht dat hij is geblokkeerd. Hij wordt dan niet door gestuurd en zijn IP wordt toegevoegd aan de 'geblokkeerde' statistieken. Voorbeeld: <b>1</b>");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Land Condities");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "2-letter land code in hoofdletters (Bv: <b>NL</b>)");
DEFINE('_JW_STATS_INTERNAL',"Intern");
DEFINE('_JW_STATS_FROM',"Van");
DEFINE('_JW_STATS_TO',"Naar");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Toevoegen aan doelen");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Voeg doel toe voor dit land");
DEFINE('_JW_MENU_REPORT_BUG',"Melden fouten of kenmerken");
DEFINE('_JW_GOALS_COUNTRY',"Land");

/* Dutch translations 1.2.8b_12 */

DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Als U de namen van de landen in hoofdletters wilt in de frontend (Bv. NEDERLAND, DUITSLAND in plaats van Nederland, Duitsland)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Tijd in seconden die nodig is om de gebruikers in de frontend te cachen");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Oorspronkelijke waarde te zien in Totaal: in de frontend. Handig als U migreert van een andere statistiek programma. (Bv: 20000). Zet op 0 als U deze feature niet wil gebruiken.");
DEFINE('_JW_DESC_IGNORE_USER', "Negeer gebruikers uit de lijst in deze textbox. Een per regel. (Bv: mijzelf {line break} mark_*)");
DEFINE('_JW_FRONTEND_USERS_MOST', "Meest actieve gebruikers vandaag van het totaal van");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"De blokkeringen activeren gebaseerd op de woorden uit de spamwoordenlijst hieronder ?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Meest gebruikte spam woorden door spam bots gebruikt. U kan hier wildcards gebruiken, (Bv: ph?rmac*). Als de instelling hierboven is geactiveerd, zal JoomlaWatch controleren of de aanvaller een formulier heeft verstuurd (de HTTP POST request) naar uw website met enkele van deze spam woorden. (Is van toepassing als het formulier alleen de Joomla-gebaseerde website laadt - forum, commentaar, maar is effectief in het blokkeren van spam bots die elk type formulier willen versturen)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Een link in de frontend gebruikers module - staat U toe een URL te specificeren, welke open is wanneer de gebruiker op de gebruikersnaam klikt. Moet wel de string {user} bevatten, deze wordt vervangen door de juiste gebruikersnaam. (Bv: index.php option=com_comprofiler&task=userProfile&user={user}) ");


/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Trefzinnen");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximale waarden in de geschiedenis tab (Voorbeeld: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In het aantal bezoeken Toon alleen laatst bezochte pagina, niet alle");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In het aantal bezoeken, verberg zich herhalende sitenamen in de bezochte pagina titel");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximaal aantal bezoekers te bewaren in de database voor Bezoekers Geschiedenis. Wees voorzichtig met deze instelling, als je veel verkeer genereerd, kan het echt snel groeien. Controleer altijd hoeveel gegevens de geschiedenis tabel bevat in Status.");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Behoud Databasetabellen bij deïnstallatie. Vink deze optie aan voor het deïnstalleren als u een upgrade doet en u wilt uw gegevens te bewaren.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "U ontvangt nachtelijke e-mails met rapporten van de voorgaande dag, die u in de ochtend kunt lezen.");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "E-mailadres waar u deze rapporten op wilt ontvangen.");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Voeg alleen rijen in e-mail rapporten toe waarin het percentage hoger is dan {waarde}. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Voeg alleen <b>positieve één dag</b> waarde wijzigingen in e-mail rapporten toe die hoger zijn dan {waarde} procent. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Voeg alleen <b>negatieve één dag</b> waarden toe in het e-mail rapport die lager zijn dan {waarde} procent. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Voeg alleen <b>positieve zeven dagen</b> waarden toe in het e-mail rapport die hoger zijn dan {waarde} procent. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Voeg alleen <b>negatieve zeven dagen</b> waarden toe in het e-mail rapport die lager zijn dan {waarde} procent. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Voeg alleen <b>positieve dertig dagen</b> waarden toe in het e-mail rapport die hoger zijn dan {waarde} procent. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Voeg alleen <b>negatieve dertig dagen</b> waarden toe in het e-mail rapport die lager zijn dan {waarde} procent. Stel in op 0 als u deze functie niet wilt gebruiken <i>(voorbeeld: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functioneel in advertentie vrije versie)</b> Schakel deze instelling in als u de logo koppeling wilt maken met het attribuut rel='nofollow'");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum aantal tekens van de e-mail naam regel. Verander dit als je e-mail programma bericht venster te klein is");

DEFINE('_JW_MENU_HISTORY', "Geschiedenis");
DEFINE('_JW_MENU_EMAILS', "E-mails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"Deze IP's werden geblokkeerd door anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Bezoekers Geschiedenis");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Toont slechts %d laatste records. Om deze waarde te veranderen, ga naar Instellingen -> Geschiedenis & Prestaties -> HISTORY_MAX_DB_RECORDS. Wees voorzichtig, deze instelling beïnvloedt laadtijden van de onderstaande gegevens.");
DEFINE('_JW_MENU_BUG', "Rapporteer Bug");
DEFINE('_JW_MENU_FEATURE', "Vraag om extra Functie");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Trefwoorden");

DEFINE('_JW_BLOCKING_UNBLOCK',"deblokkeren");
DEFINE('_JW_STATS_KEYPHRASE ',"Sleutelwoord");
DEFINE('_JW_STATUS_DATABASE',"Database status");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"tabel naam");
DEFINE('_JW_STATUS_DATABASE_ROWS',"regels");
DEFINE('_JW_STATUS_DATABASE_DATA',"data");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"totaal");

DEFINE('_JW_EMAIL_REPORTS',"E-mail Rapporten");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Gegenereerd en gefilterd e-mail verslag van gisteren");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"E-mail Waarde Filters");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"waarde");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"procent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"na 1 dag");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"na 7 dagen");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"na 30 dagen");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch heeft vandaag %d spammer hits geblokkeerd, totaal: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Geblokkeerde IP Adressen");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam instellingen");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX updates verkeer");


DEFINE('_JW_HISTORY_PREVIOUS',"vorige");
DEFINE('_JW_HISTORY_NEXT',"volgende");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Aantal kolommen voor landen");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Aantal regels voor landen");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Toon land namen of niet");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Toon vlaggen eerst, dan de percentages");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET inversed condition");
DEFINE('_JW_GOALS_POST_INVERSED', "POST inversed condition");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Title inversed condition");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Username inversed condition");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Came from inversed condition");

DEFINE('_JW_STATS_MAP', "Last Visit Map");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Please enter <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> key to display last visit map:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"store key");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Please enter valid ipinfodb key you obtained from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Submitted form fields:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameters:");
DEFINE('_JW_VISIT_ADD_PAGE'," Add page as goal");
DEFINE('_JW_VISIT_BLOCK_IP'," Block this IP Address");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Add this submitted form variable as goal");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Add this URL parameter as goal");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," WARNING: The value you entered is not a number. JoomlaWatch will not work properly!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; This is a 15-day Evaluation Version. Days Left: <b>%d</b>. Please purchase the lifetime <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Your trial version has expired. Please purchase JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"License activated successfully. Thank you");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: the license key and your domain don't match.</b><br/>Did you enter the same domain name into activation form as one you see below? Please contact: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"If you are seeing the message above for too long, your live site may be wrong.
                    Open the components/com_joomlawatch/config.php
                    uncomment, and set your actual live site. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Warning: site in your browser and live site in configuration: %s and %s don't match.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Set live site to: %s and continue...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Remove Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flow");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphs");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Components");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Write a ");

DEFINE('_JW_FLOW_TRAFFIC',"Traffic Flow");
DEFINE('_JW_FLOW_SELECT_PAGE',"Select page:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root outgoing links count:");
DEFINE('_JW_FLOW_NESTING',"Nesting level:");
DEFINE('_JW_FLOW_SCALE',"Scale:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Ad-free version");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Thank you very much for your donation!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registration key for your domain %s is: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Now you can remove backlink or hide JoomlaWatch logo in frontend from Settings ");


DEFINE('_JW_SIZES_LAST_CHECK',"Last check was performed on:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Size of component/module in /administrator directory");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Component");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Size");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Refresh All");

DEFINE('_JW_SIZEDATABASE_TABLE',"Table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Size");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Day Change");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Day Change");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Day Change");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"no data");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Refresh All");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Module");
DEFINE('_JW_SIZEMODULES_SIZE',"Size");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Refresh");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Last visit map ipinfodb.com key from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");

/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");

?>