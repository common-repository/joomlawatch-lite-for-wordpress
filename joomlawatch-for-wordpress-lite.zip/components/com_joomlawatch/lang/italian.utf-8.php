<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistiche");
DEFINE('_JW_MENU_GOALS', "Obiettivi");
DEFINE('_JW_MENU_SETTINGS', "Opzioni");
DEFINE('_JW_MENU_CREDITS', "Riconoscimenti");
DEFINE('_JW_MENU_FAQ', "FAQ");
DEFINE('_JW_MENU_DOCUMENTATION', "Documentazione");
DEFINE('_JW_MENU_LICENSE', "Licenza PRO");
DEFINE('_JW_MENU_DONATORS', "Donazioni");
DEFINE('_JW_MENU_SUPPORT', "Supporta JoomlaWatch per eliminare le pubblicità nel Backend.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Ultimi visitatori");
DEFINE('_JW_VISITS_BOTS', "Bot");
DEFINE('_JW_VISITS_CAME_FROM', "Provenienza");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Non hai pubblicato il modulo JoomlaWatch, quindi non viene registrata alcuna statistica! Vai nella sezione Moduli e pubblicalo su tutte le pagine");
DEFINE('_JW_VISITS_PANE_LOADING', "Carico le visite...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Statistiche della settimana");
DEFINE('_JW_STATS_WEEK', "Settimana");
DEFINE('_JW_STATS_THIS_WEEK', "questa settimana");
DEFINE('_JW_STATS_UNIQUE', "visitatori");
DEFINE('_JW_STATS_LOADS', "accessi");
DEFINE('_JW_STATS_HITS', "clic");
DEFINE('_JW_STATS_TODAY', "oggi");
DEFINE('_JW_STATS_FOR', "del");
DEFINE('_JW_STATS_ALL_TIME', "Statistiche globali");
DEFINE('_JW_STATS_EXPAND', "espandi");
DEFINE('_JW_STATS_COLLAPSE', "restringi");
DEFINE('_JW_STATS_URI', "Pagine");
DEFINE('_JW_STATS_COUNTRY', "Nazioni");
DEFINE('_JW_STATS_USERS', "Visitatori");
DEFINE('_JW_STATS_REFERERS', "Provenienza");
DEFINE('_JW_STATS_IP', "IP");
DEFINE('_JW_STATS_BROWSER', "Browser");
DEFINE('_JW_STATS_OS', "S.O.");
DEFINE('_JW_STATS_KEYWORDS', "Parole chiave");
DEFINE('_JW_STATS_GOALS', "Obiettivi");
DEFINE('_JW_STATS_TOTAL', "Totali");
DEFINE('_JW_STATS_DAILY', "Statistiche di oggi");
DEFINE('_JW_STATS_DAILY_TITLE', "Statistiche del");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Statistiche globali");
DEFINE('_JW_STATS_LOADING', "Carico...");
DEFINE('_JW_STATS_LOADING_WAIT', "carico... attendi");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blocco IP");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Inserisci IP manualmente");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Inserisci l'IP che vuoi bloccare. (es. 217.242.11.54 o 217.* o 217.242.* per bloccare tutti gli IP con il carattere jolly)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Vuoi davvero bloccare/sbloccare ");
DEFINE('_JW_STATS_PANE_LOADING', "Carico le statistiche...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Opzioni");
DEFINE('_JW_SETTINGS_DEFAULT', "Impostazione predefinita");
DEFINE('_JW_SETTINGS_SAVE', "Salva");
DEFINE('_JW_SETTINGS_APPEARANCE', "Aspetto");
DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Storia &amp; prestazioni");
DEFINE('_JW_SETTINGS_ADVANCED', "Avanzate");
DEFINE('_JW_SETTINGS_IGNORE', "Ignora");
DEFINE('_JW_SETTINGS_BLOCKING', "Blocca");
DEFINE('_JW_SETTINGS_EXPERT', "Modalità Esperto");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Vuoi davvero azzerare tutte le statistiche e i dati dei visitatori?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Azzera tutto");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Azzera tutte le statistiche e i dati dei visitatori");
DEFINE('_JW_SETTINGS_LANGUAGE', "Lingua");
DEFINE('_JW_SETTINGS_SAVED', "Impostazioni salvate");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Aggiungi il tuo IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "all'elenco.");

# Other / mostly general
DEFINE('_JW_TITLE', "Monitor AJAX in tempo reale per Joomla");
DEFINE('_JW_BACK', "Indietro");
DEFINE('_JW_ACCESS_DENIED', "Non hai i permessi per visualizzare!");
DEFINE('_JW_LICENSE_AGREE', "Accetto i termini e le &amp; condizioni");
DEFINE('_JW_LICENSE_CONTINUE', "Continua");
DEFINE('_JW_SUCCESS', "Operazione compiuta");
DEFINE('_JW_RESET_SUCCESS', "Tutte le statistiche e i dati sui visitatori sono state cancellate");
DEFINE('_JW_RESET_ERROR', "Si è verificato un problema e i dati NON sono stati cancellati.");
DEFINE('_JW_CREDITS_TITLE', "Riconoscimenti");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Statistiche giornaliere e settimanali di");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "Permesso AJAX negato: visualizza le statistiche nel dominio specificato nel file configuration.php di Joomla - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Forse hai dimenticato di digitare www. prima del nome di dominio. Javascript sta tentando di accedere ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "da");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "ciò che gli fa pensare che si tratti di un dominio differente.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Scarica l'ultima versione da");
DEFINE('_JW_HEADER_CAST_YOUR', "Invia il tuo");
DEFINE('_JW_HEADER_VOTE', "Voto");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Clicca per visualizzare il messaggio");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Passa sopra con il mouse per visualizzare il messaggio");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "rispetto a ieri");
DEFINE('_JW_TOOLTIP_HELP', "Accede alla guida online per");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Chiudi");
DEFINE('_JW_TOOLTIP_PRINT', "Stampa");

# Goals
DEFINE('_JW_GOALS_INSERT', "Nuovo obiettivo");
DEFINE('_JW_GOALS_UPDATE', "Aggiorna l'obiettivo ");
DEFINE('_JW_GOALS_ACTION', "Azione");
DEFINE('_JW_GOALS_TITLE', "Nuovo obiettivo");
DEFINE('_JW_GOALS_NEW', "Nuovo obiettivo");
DEFINE('_JW_GOALS_RELOAD', "Ricarica");
DEFINE('_JW_GOALS_ADVANCED', "Avanzato");
DEFINE('_JW_GOALS_NAME', "Nome");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "Condizione URI");
DEFINE('_JW_GOALS_GET_VAR', "Variabile GET");
DEFINE('_JW_GOALS_GET_CONDITION', "Condizione GET");
DEFINE('_JW_GOALS_POST_VAR', "Variabile POST");
DEFINE('_JW_GOALS_POST_CONDITION', "Condizione POST");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Condizione TITLE");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Condizione USERNAME");
DEFINE('_JW_GOALS_IP_CONDITION', "Condizione IP");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Condizione FROM");
DEFINE('_JW_GOALS_BLOCK', "Blocca");
DEFINE('_JW_GOALS_REDIRECT', "Reindirizza all'URL");
DEFINE('_JW_GOALS_HITS', "Clic");
DEFINE('_JW_GOALS_ENABLED', "Attivo");
DEFINE('_JW_GOALS_EDIT', "Modifica");
DEFINE('_JW_GOALS_DELETE', "Cancella");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Perderai tutte le statistiche recenti per questo obiettivo. Vuoi eliminarlo davvero?");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Nazione di provenienza");
DEFINE('_JW_FRONTEND_VISITORS', "Numero di visitatori");
DEFINE('_JW_FRONTEND_TODAY', "Oggi");
DEFINE('_JW_FRONTEND_YESTERDAY', "Ieri");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Questa settimana");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Scorsa settimana");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Questo mese");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Scorso mese");
DEFINE('_JW_FRONTEND_TOTAL', "Totale");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch è in modalità debug. In questo modo puoi scoprire le cause degli errori. Per disattivarla, modifica la voce JOOMLAWATCH_DEBUG in /components/com_joomlawatch/config.php da 1 a 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Numero massimo di righe da mostrare quando espandi le statistiche.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Tutti gli indirizzi IP che nei giorni passati hanno effettuato un numero di clic minore di questo numero saranno cancellati dalla cronologia degli IP.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Tutti gli URL che nei giorni passati hanno effettuato un numero di clic minore di questo numero saranno cancellati dalla cronologia degli IP.");
DEFINE('_JW_DESC_IGNORE_IP', "Escludi alcuni indirizzi IP dalle statistiche, separandoli andando a capo. Puoi usare i caratteri jolly. <br/>Es. 192.* ignorerà 192.168.51.31, 192.168.16.2, ecc..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Tempo di aggiornamento dei visitatori (in millisecondi). L'impostazione predefinita è 2000. Si raccomanda particolare cautela nel modificare questo valore. Al termine, ricarica il Backend di JoomlaWatch.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Tempo di aggiornamento delle statistiche (in millisecondi). L'impostazione predefinita è 4000. Si raccomanda particolare cautela nel modificare questo valore. Al termine, ricarica il Backend di JoomlaWatch.");
DEFINE('_JW_DESC_MAXID_BOTS', "Quante visite dei bot vuoi mantenere nel database.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Quante visite reali vuoi mantenere nel database.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Quanti bot vuoi visualizzare nel Backend.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Quanti visitatori reali vuoi visualizzare nel Backend.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Numero massimo di caratteri da visualizzare nei titoli e negli URI lunghi.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Numero massimo di caratteri da visualizzare nel pannello delle statistiche a destra.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Per quanti giorni vuoi mantenere le statistiche nel database. 0 = per sempre.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Se il tuo fuso orario è diverso da quello del server che ospita il sito (imposta un valore positivo o negativo in ore).");
DEFINE('_JW_DESC_WEEK_OFFSET', "Compensazione della settimana. Il calendario/(3600*24*7) parte dal 1.1.1970. Con questa compensazione, puoi far partire la settimana dal lunedì.");
DEFINE('_JW_DESC_DAY_OFFSET', "Compensazione del giorno. Il calendario/(3600*24) parte dal 1.1.1970. Con questa compensazione, puoi far partire la giornata alle 00:00.");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Usa un'icona vuota (1x1 px) nel Frontend");
DEFINE('_JW_DESC_IP_STATS', "Abilita le statistiche sugli indirizzi IP. In alcune nazioni, la legge proibisce di mantenere gli IP in un database per un tempo maggiore di quello consentito. Utilizza questa opzione a tuo rischio e pericolo.");
DEFINE('_JW_DESC_HIDE_ADS', "Questa opzione nasconde le pubblicità nel Backend, nel caso ti infastidiscano. Mantenendole, supporti il futuro sviluppo di questo componente. Grazie.");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Togli il segno di spunta se vuoi visualizzare i messaggi quando passi il mouse sopra un'opzione, invece di cliccarci.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "L'impostazione predefinita è 'REDIRECT_URL', che è consigliabile se utilizzi la riscrittura delle URL. Se è collegata esclusivamente alla pagina index.php, puoi usare 'SCRIPT_URL'.");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Messaggio visualizzato per bloccare un utente o per fornire ulteriori informazioni sul blocco.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Larghezza messaggi");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Altezza messaggi");
DEFINE('_JW_DESC_TOOLTIP_URL', "Qui puoi inserire una URL qualsiasi per visualizzare l'indirizzo IP del visitatore. {ip} sarà sostituito dall'indirizzo IP del visitatore. Es. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Qui puoi inserire una URL qualsiasi da ignorare nelle statistiche. Puoi usare i caratteri jolly * e ?. Es.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Specifica un nome per visualizzare l'obiettivo nelle statistiche.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Tutto ciò che viene dopo il tuo nome di dominio. Per http://www.codegravity.com/projects/ l'URI è: /projects/ (Esempio: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "Puoi trovare la variabile GET nell'indirizzo URL, solitamente dopo un ? o &amp;. Es. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Puoi usare <u>*</u> in questo capo per esaminare tutti i valori della variabile GET. (Esempio: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Il valore per il campo precedente. (Esempio: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Molto simile al precedente, ma qui cerchiamo i valori inseriti nei form. Quindi, se hai un form sul tuo sito, ha un campo &lt;input type='text' name='<u>experiences</u>' /&gt;. (Esempio: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Il valore per il campo POST. Per esempio se vuoi controllare se l'utente ha usato java. (Esempio: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Il titolo di una pagina. (Esempio: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Il nome di un utente che ha effettuato l'accesso. (Esempio: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "L'indirizzo IP di un utente. (Esempio: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "L'URL da cui proviene l'utente. (Esempio: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "L'utente viene reindirizzato su un URL specificata da te. Questa funzione ha una priorità maggiore rispetto al blocco. (Esempio: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Quanti caratteri visualizzare nella tabella degli obiettivi.");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Collegamento a codegravity.com. Puoi disattivarlo, ma ti saremmo grati se lo lasciassi attivo. Grazie.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Mostra le statistiche globali per le nazioni nel modulo del Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Inverti l'ordine di visualizzazione Visitatori/Nazioni nel Frontend. Se togli il segno di spunta, i Visitatori appariranno per primi.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Numero di nazioni da visualizzare nel Frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Mostra il numero di visitatori per ogni nazione nel modulo del Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Tempo in secondi per il fetching della cache del numero di visitatori per nazione nel modulo del Frontend");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Tempo in secondi per il fetching della cache del numero di visitatori nel modulo del Frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Mostra i visitatori di oggi nel Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Mostra i visitatori di ieri nel Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Mostra i visitatori della settimana in corso nel Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Mostra i visitatori della settimana scorsa nel Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Mostra i visitatori del mese in corso nel Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Mostra i visitatori del mese scorso nel Frontend. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Visualizza il numero totale di visitatori da quando hai installato JoomlaWatch. Se cambi questa impostazione, sarà visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "File della lingua da utilizzare. I file della lingua si trovano in /components/com_joomlawatch/lang/. Se vuoi crearne uno nuovo, copia quello predefinito (english.php), rinominalo (per es. italian.php) e posizionalo in questa directory. Quindi, traduci tutti i valori chiave sulla destra.");
DEFINE('_JW_DESC_GOALS', "Gli obiettivi ti permettono di impostare dei parametri specifici. Quando questi parametri si verificano, il contatore degli obiettivi aumenta. In questo modo, puoi verificare se un utente ha visitato un'URL specifica, se ha inviato un determinato valore, se è associato a un nome utente particolare o proviene da un certo indirizzo. Puoi anche bloccare alcuni utenti o reindirizzarli verso altre URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "Puoi usare i caratteri jolly * e ? in tutti i campi, tranne quello del nome. Per esempio: ?ear per near, tear, ecc. oppure p*r per pr, peer, pear, ecc.");
DEFINE('_JW_DESC_GOALS_BLOCK', "Impostalo su 1 se vuoi bloccare il visitatore e impedirgli di visualizzare il resto del sito a parte un avviso del blocco (senza reindirizzamento). Il suo IP verrà aggiunto alle statistiche degli IP bloccati. (Esempio: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Condizione COUNTRY");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Codice maiuscolo di 2 lettere per la nazione (Es: <b>IT</b>)");
DEFINE('_JW_STATS_INTERNAL',"Collegamenti interni");
DEFINE('_JW_STATS_FROM',"Da");
DEFINE('_JW_STATS_TO',"A");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Aggiungi agli obiettivi");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Aggiungi un obiettivo per questa nazione");
DEFINE('_JW_MENU_REPORT_BUG',"Segnala bug");
DEFINE('_JW_GOALS_COUNTRY',"Nazione");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Se vuoi i nomi delle nazioni in maiuscolo nel Frontend (Es: GERMANY, UNITED KINGDOM invece di Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Tempo in secondi per il fetching della cache degli utenti nel Frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Valore iniziale del contatore Totale del Frontend. Utile se stai effettuando una migrazione da un altro strumento per le statistiche. (Es.: 20000). Se non vuoi sfruttare questa funzione, reimposta il valore a 0.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignora gli utenti elencati in questa casella di testo. Inseriscili uno per linea. (Es.: io {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Gli utenti più attivi di oggi su un totale di");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Abilitare il ban in base alle parole elencate qui sotto?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Le parole chiave più comuni utilizzate dagli spambot. Puoi usare i caratteri jolly (Es.: ph?rmac*). Se l'opzione qui sopra è attivata, JoomlaWatch monitorerà ogni inserimento di queste parole in un form sul tuo sito (la richiesta HTTP POST). Progettato per i form creati con Joomla: forum, commenti, ecc. In ogni caso, è molto efficace contro gli spambot che tentino di inviare messaggi in qualsiasi tipo di form)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Un collegamento nel modulo Utenti del Frontend. Ti permette di specificare un'URL, che si apre quando l'utente clicca sul suo nome. Deve contenere il valore {user}, che sarà sostituito dal vero nome utente. (Es. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Keyphrases");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum values in history tab (Example: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In visits show only last page visited, not all");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In visits hide repetitive sitename in visited page title");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximum nuber of visitors to keep in database for Visit History. Be careful with this setting, if you have high traffic, it can grow really fast. Always check how much data the history table contains in Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Keep Database Tables on uninstall. Check this option before uninstall if you are doing an upgrade and want to keep your data.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "You'll receive nightly emails with reports for previous day, which you can read in the morning");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Email address to which you'll receive these reports");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Only include rows in email reports where percentage is higher than {value}. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Only include <b>positive one day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Only include <b>negative one day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Only include <b>positive seven day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Only include <b>negative seven day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Only include <b>positive thirty day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Only include <b>negative thirty day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functional in PRO version)</b> Enable this setting if you want to make the logo link rendered with attribute rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum characters of email row name. Change this if your email client message window is too small");

DEFINE('_JW_MENU_HISTORY', "History");
DEFINE('_JW_MENU_EMAILS', "Emails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"These IPs were blocked by anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Visitors History");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Showing only %d last records.
                To change this value, go to Settings -&gt; History &amp; Performance -&gt; HISTORY_MAX_DB_RECORDS . Be careful, this setting affects load times of the data below.  ");
DEFINE('_JW_MENU_BUG', "Report Bug");
DEFINE('_JW_MENU_FEATURE', "Request Feature");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Keywords");

DEFINE('_JW_BLOCKING_UNBLOCK',"unblock");
DEFINE('_JW_STATS_KEYPHRASE ',"Keyphrase");
DEFINE('_JW_STATUS_DATABASE',"Database status");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"table name");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rows");
DEFINE('_JW_STATUS_DATABASE_DATA',"data");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"total");

DEFINE('_JW_EMAIL_REPORTS',"Email Reports");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generated filtered email report from yesterday");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Email Value Filters");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"value");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-day change");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-day change");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-day change");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch has blocked %d spammer hits today, total: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blocked IP Adresses");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Settings");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX updates traffic");


DEFINE('_JW_HISTORY_PREVIOUS',"previous");
DEFINE('_JW_HISTORY_NEXT',"next");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Number of columns of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Number of rows of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Display country names or not");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Display flags first, then percents");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET inversed condition");
DEFINE('_JW_GOALS_POST_INVERSED', "POST inversed condition");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Title inversed condition");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Username inversed condition");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Came from inversed condition");

DEFINE('_JW_STATS_MAP', "Last Visit Map");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Please enter <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> key to display last visit map:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"store key");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Please enter valid ipinfodb key you obtained from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Submitted form fields:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameters:");
DEFINE('_JW_VISIT_ADD_PAGE'," Add page as goal");
DEFINE('_JW_VISIT_BLOCK_IP'," Block this IP Address");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Add this submitted form variable as goal");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Add this URL parameter as goal");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," WARNING: The value you entered is not a number. JoomlaWatch will not work properly!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; This is a 15-day Evaluation Version. Days Left: <b>%d</b>. Please purchase the lifetime <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Your trial version has expired. Please purchase JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"License activated successfully. Thank you");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: the license key and your domain don't match.</b><br/>Did you enter the same domain name into activation form as one you see below? Please contact: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"If you are seeing the message above for too long, your live site may be wrong.
                    Open the components/com_joomlawatch/config.php
                    uncomment, and set your actual live site. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Warning: site in your browser and live site in configuration: %s and %s don't match.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Set live site to: %s and continue...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Remove Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flow");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphs");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Components");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Write a ");

DEFINE('_JW_FLOW_TRAFFIC',"Traffic Flow");
DEFINE('_JW_FLOW_SELECT_PAGE',"Select page:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root outgoing links count:");
DEFINE('_JW_FLOW_NESTING',"Nesting level:");
DEFINE('_JW_FLOW_SCALE',"Scale:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Ad-free version");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Thank you very much for your donation!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registration key for your domain %s is: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Now you can remove backlink or hide JoomlaWatch logo in frontend from Settings ");


DEFINE('_JW_SIZES_LAST_CHECK',"Last check was performed on:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Size of component/module in /administrator directory");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Component");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Size");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Refresh All");

DEFINE('_JW_SIZEDATABASE_TABLE',"Table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Size");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Day Change");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Day Change");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Day Change");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"no data");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Refresh All");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Module");
DEFINE('_JW_SIZEMODULES_SIZE',"Size");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Refresh");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Last visit map ipinfodb.com key from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");

?>