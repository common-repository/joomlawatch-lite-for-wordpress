<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );



# Main Menu

DEFINE('_JW_MENU_STATS', "Statistiken");

DEFINE('_JW_MENU_GOALS', "Ziele");

DEFINE('_JW_MENU_SETTINGS', "Einstellungen");

DEFINE('_JW_MENU_CREDITS', "Credits");

DEFINE('_JW_MENU_FAQ', "FAQ");

DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentation");

DEFINE('_JW_MENU_LICENSE', "Werbefreie Lizens");

DEFINE('_JW_MENU_DONATORS', "Spender");

DEFINE('_JW_MENU_SUPPORT', "Unterstützen Sie JoomlaWatch und erhalten Sie einen Backend-Bereich ohne Werbeeinblendungen.");



# Left visitors real-time window

DEFINE('_JW_VISITS_VISITORS', "Neue Besucher");

DEFINE('_JW_VISITS_BOTS', "Bots");

DEFINE('_JW_VISITS_CAME_FROM', "Herkunft");

DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Ihr JoomlaWatch Modul ist nicht aktiviert! Es werden keine neuen Statistiken aufgezeichnet. Um Ihr JoomlaWatch Modul zu aktivieren, wechseln Sie in den Modul-Bereich und aktivieren Sie das Modul auf allen Seiten.");

DEFINE('_JW_VISITS_PANE_LOADING', "Lade Visits...");



# Right stats window

DEFINE('_JW_STATS_TITLE', "wöchentliche Statistik");

DEFINE('_JW_STATS_WEEK', "Woche");

DEFINE('_JW_STATS_THIS_WEEK', "Diese Woche");

DEFINE('_JW_STATS_UNIQUE', "Einmalig");

DEFINE('_JW_STATS_LOADS', "Ladevorgänge");

DEFINE('_JW_STATS_HITS', "Besuche");

DEFINE('_JW_STATS_TODAY', "Heute");

DEFINE('_JW_STATS_FOR', "am");

DEFINE('_JW_STATS_ALL_TIME', "Gesamtstatistik");

DEFINE('_JW_STATS_EXPAND', "ausklappen");

DEFINE('_JW_STATS_COLLAPSE', "zuklappen");

DEFINE('_JW_STATS_URI', "Seiten");

DEFINE('_JW_STATS_COUNTRY', "Länder");

DEFINE('_JW_STATS_USERS', "Benutzer");

DEFINE('_JW_STATS_REFERERS', "verweisende Websites");

DEFINE('_JW_STATS_IP', "IPs");

DEFINE('_JW_STATS_BROWSER', "Browsers");

DEFINE('_JW_STATS_OS', "Betriebssysteme");

DEFINE('_JW_STATS_KEYWORDS', "Schlüsselbegriffe");

DEFINE('_JW_STATS_GOALS', "Ziele");

DEFINE('_JW_STATS_TOTAL', "Total");

DEFINE('_JW_STATS_DAILY', "Tagesstatistik");

DEFINE('_JW_STATS_DAILY_TITLE', "Tagesstatistik");

DEFINE('_JW_STATS_ALL_TIME_TITLE', "Gesamtstatistik");

DEFINE('_JW_STATS_LOADING', "Ladevorgang...");

DEFINE('_JW_STATS_LOADING_WAIT', "Ladevorgang... Bitte warten");

DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP-Blockierung");

DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "IP manuell eingeben");

DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Geben Sie die zu blockierende IP-Adresse ein (z.B. 217.242.11.54 oder 217.* oder 217.242.* um alle IPs, die mit dem Platzhalter übereinstimmen, zu blockieren).");

DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Wollen Sie diese IP wirklich blockieren ");

DEFINE('_JW_STATS_PANE_LOADING', "Lade Statistiken...");



# Settings

DEFINE('_JW_SETTINGS_TITLE', "Einstellungen");

DEFINE('_JW_SETTINGS_DEFAULT', "Standard");

DEFINE('_JW_SETTINGS_SAVE', "Speichern");

DEFINE('_JW_SETTINGS_APPEARANCE', "Erscheinungsbild");

DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");

DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Chronik & Leistung");

DEFINE('_JW_SETTINGS_ADVANCED', "Fortgeschritten");

DEFINE('_JW_SETTINGS_IGNORE', "Ignorieren");

DEFINE('_JW_SETTINGS_BLOCKING', "Blockieren");

DEFINE('_JW_SETTINGS_EXPERT', "Experteneinstellung");

DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Wollen Sie wirklich alle Statistiken und Besucherdaten zurücksetzen?");

DEFINE('_JW_SETTINGS_RESET_ALL', "Alles zurücksetzen");

DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Alle Statistiken & Besucherdaten zurücksetzen");

DEFINE('_JW_SETTINGS_LANGUAGE', "Sprache");

DEFINE('_JW_SETTINGS_SAVED', "Einstellungen wurden gespeichert");

DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Fügen Sie ihre IP");

DEFINE('_JW_SETTINGS_TO_THE_LIST', "zur Liste hinzu.");



# Other / mostly general

DEFINE('_JW_TITLE', "Ein Echtzeit AJAX-Joomla-Monitor");

DEFINE('_JW_BACK', "zurück");

DEFINE('_JW_ACCESS_DENIED', "Sie haben nicht die erforderlichen Zugriffsrechte !");

DEFINE('_JW_LICENSE_AGREE', "I erkläre mich mit den I Agree to the terms & conditions above");

DEFINE('_JW_LICENSE_CONTINUE', "weiter");

DEFINE('_JW_SUCCESS', "Operation erfolgreich");

DEFINE('_JW_RESET_SUCCESS', "Alle Statistiken und Besucherdaten wurden erfolgreich gelöscht");

DEFINE('_JW_RESET_ERROR', "Daten wurden NICHT erfolgreich gelöscht. Es ist ein Fehler aufgetreten.");

DEFINE('_JW_CREDITS_TITLE', "Credits");

DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Tages- und Wochenstatistik von");

DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX Zugriff verweigert: Bitte betrachten Sie die Statistiken von ihrer in der configuration.php eingestellten Domain - ");

DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Vielleicht haben Sie einfach nur vergessen das www. vor den Domainnamen zu setzen. Ihr Javascript versucht zuzugreifen auf");

DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "von");

DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "was dafür sorgt, dass angenommen wird, es handle sich um eine andere Domain.");



# Header

DEFINE('_JW_HEADER_DOWNLOAD', "Für die neueste Version, besuchen Sie");

DEFINE('_JW_HEADER_CAST_YOUR', "Geben Sie Ihre");

DEFINE('_JW_HEADER_VOTE', "Stimme hier ab");



# Tooltips

DEFINE('_JW_TOOLTIP_CLICK', "Klicken, um Tooltip zu öffnen");

DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Maus hierher bewegen, um Tooltip zu öffnen");

DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "yesterday's increase");

DEFINE('_JW_TOOLTIP_HELP', "Öffnet die Online-Hilfe für den Bereich");

DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Dieses Fenster schließen");

DEFINE('_JW_TOOLTIP_PRINT', "Drucken");



# Goals

DEFINE('_JW_GOALS_INSERT', "Ziel einfügen");

DEFINE('_JW_GOALS_UPDATE', "bearbeite Ziel:");

DEFINE('_JW_GOALS_ACTION', "Zielaktionen");

DEFINE('_JW_GOALS_TITLE', "neues Ziel");

DEFINE('_JW_GOALS_NEW', "neues Ziel");

DEFINE('_JW_GOALS_RELOAD', "neu laden");

DEFINE('_JW_GOALS_ADVANCED', "Fortgeschritten");

DEFINE('_JW_GOALS_NAME', "Name");

DEFINE('_JW_GOALS_ID', "ID");

DEFINE('_JW_GOALS_URI_CONDITION', "URI-Bedingung");

DEFINE('_JW_GOALS_GET_VAR', "GET-Variable");

DEFINE('_JW_GOALS_GET_CONDITION', "GET-Bedingung");

DEFINE('_JW_GOALS_POST_VAR', "POST-Variable");

DEFINE('_JW_GOALS_POST_CONDITION', "POST-Bedingung");

DEFINE('_JW_GOALS_TITLE_CONDITION', "Titel-Bedingung");

DEFINE('_JW_GOALS_USERNAME_CONDITION', "Username-Bedingung");

DEFINE('_JW_GOALS_IP_CONDITION', "IP-Bedingung");

DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Herkunfts-Bedingung");

DEFINE('_JW_GOALS_BLOCK', "IP-Blockierung");

DEFINE('_JW_GOALS_REDIRECT', "URL-Weiterleitung");

DEFINE('_JW_GOALS_HITS', "Treffer");

DEFINE('_JW_GOALS_ENABLED', "aktivieren");

DEFINE('_JW_GOALS_EDIT', "bearbeiten");

DEFINE('_JW_GOALS_DELETE', "löschen");

DEFINE('_JW_GOALS_DELETE_CONFIRM', "Sie werden alle bisherigen Statistikdaten für dieses Ziel verlieren. Wollen Sie wirklich die Löschung bestätigen für das Ziel mit der ID-Nr.");



# Frontend

DEFINE('_JW_FRONTEND_COUNTRIES', "Länder");

DEFINE('_JW_FRONTEND_VISITORS', "Besucher");

DEFINE('_JW_FRONTEND_TODAY', "heute");

DEFINE('_JW_FRONTEND_YESTERDAY', "gestern");

DEFINE('_JW_FRONTEND_THIS_WEEK', "diese Woche");

DEFINE('_JW_FRONTEND_LAST_WEEK', "letzte Woche");

DEFINE('_JW_FRONTEND_THIS_MONTH', "dieser Monat");

DEFINE('_JW_FRONTEND_LAST_MONTH', "letzter Monat");

DEFINE('_JW_FRONTEND_TOTAL', "Total");



# Settings description - quite long

DEFINE('_JW_DESC_DEBUG', "JoomlaWatch befindet sich im Fehlersuchmodus. Auf diesem Wege können Sie Fehlerquellen aufspüren. Um diesen Modus zu deaktivieren, ändern Sie bitte den Wert JOOMLAWATCH_DEBUG in /components/com_joomlawatch/config.php von 1 auf 0");

DEFINE('_JW_DESC_STATS_MAX_ROWS', "Maximale Anzahl an Zeilen, die dargestellt werden, wenn die Statitiken im erweiterten Modus angezeigt werden.");

DEFINE('_JW_DESC_STATS_IP_HITS', "Alle IP-Adressen, die weniger Aufrufe als diesen Wert in den letzten Tagen hatten, werden aus der IP-Chronik gelöscht.");

DEFINE('_JW_DESC_STATS_URL_HITS', "Alle URLs, die weniger Aufrufe als diesen Wert in den letzten Tagen hatten, werden aus der IP-Chronik gelöscht.");

DEFINE('_JW_DESC_IGNORE_IP', "Bestimmte IP-Adressen von der Statistik ausschließen. Als Trenner muss eine neue Zeile eingefügt werden. <br/> Sie können Blatzhalter benutzen. Bei 192.* werden z.B. die IP-Adressen 192.168.51.31, 192.168.16.2, ... (und so weiter) ignoriert.");

DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Besucher-Aktualisierungszeit in Millisekunden. Die Standard-Einstellung ist <b>2000</b>. Seien Sie bitte vorsichtig mit dieser Funktion. Nach einer Änderung müssen Sie das JoomlaWatch-Backend neu laden.");

DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Statistik-Aktualisierungszeit in Millisekunden. Die Standard-Einstellung ist <b>4000</b>. Seien Sie bitte vorsichtig mit dieser Funktion. Nach einer Änderung müssen Sie das JoomlaWatch-Backend neu laden.");

DEFINE('_JW_DESC_MAXID_BOTS', "Anzahl der Bots, die maximal in der Datenbank gespeichert werden sollen.");

DEFINE('_JW_DESC_MAXID_VISITORS', "Anzahl der realen Besucher, die maximal in der Datenbank gespeichert werden sollen.");

DEFINE('_JW_DESC_LIMIT_BOTS', "Anzahl der Bots, die im Backend angezeigt werden sollen.");

DEFINE('_JW_DESC_LIMIT_VISITORS', "Anzahl der realen Besucher, die im Backend angezeigt werden sollen.");

DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maximale Anzahl an Buchstaben, die bei langen Titeln und URIs angezeigt werden soll.");

DEFINE('_JW_DESC_TRUNCATE_STATS', "Maximale Anzahl an Buchstaben, die rechts vom Bereich der Statistiken angezeigt werden soll.");

DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Anzahl der Tage, welche die Statistiken in der Datenbank behalten werden sollen (<b>0 = unendlich</b>).");

DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Wenn Sie sich in einer anderen Zeitzone als ihr Server befinden (positive oder negative Werte in Stunden).");

DEFINE('_JW_DESC_WEEK_OFFSET', "Verschiebung des Wochenbeginns. Die Zeitmarke/(3600*24*7) gibt die Wochennummer gerechnet vom 1.1.1970 an. Mittels einer entsprechenden Korrektur dieser Berechnung können Sie den Wochenbeginn auf Montag setzen.");

DEFINE('_JW_DESC_DAY_OFFSET', "Verschiebung des Tagesbeginns. Die Zeitmarke/(3600*24) gibt die Tagesnummer gerechnet vom 1.1.1970 an. Mittels einer entsprechenden Korrektur dieser Berechnung können Sie den jeweiligen Tag um 00:00 Uhr beginnen lassen.");

DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Ein durchsichtiges 1x1px Icon im Frontend benutzen.");

DEFINE('_JW_DESC_IP_STATS', "IP-Adress-Statistik aktivieren. Bitte beachten Sie: In manchen Ländern ist es verboten, IP-Adressen über einen längeren Zeitraum in einer Datenbank zu speichern. Benutzung auf eigene Gefahr!");

DEFINE('_JW_DESC_HIDE_ADS',"Werbung im Backend ausblenden, falls diese Sie wirklich ärgert. Sollten Sie die Werbung weiter eingeblendet lassen, so unterstützen Sie die zukünftige Entwicklung dieses Tools. Vielen Dank.");

DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Entfernen Sie dieses Häckchen, falls Sie den Tooltip bereits anzeigen lassen wollen, sobald sich die Maus über dem entsprechenden Symbol befindet. Bei aktiviertem Häckchen wird der Tooltip erst nach einem Mausklick angezeigt.");

DEFINE('_JW_DESC_SERVER_URI_KEY', "Standard ist '<b>REDIRECT_URL</b>', wenn Sie URL-Rewriting betreiben. Kann auf '<b>SCRIPT_URL</b>' gesetzt werden, wenn nur die index.php überwacht werden soll.");

DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Nachricht, die geblockten Benutzern gezeigt wird, oder weitere Informationen, warum Sie diese Benutzer blocken.");

DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Breite des Tooltips");

DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Höhe des Tooltips");

DEFINE('_JW_DESC_TOOLTIP_URL', "Sie können hier jede URL einfügen, um die IP des Besuchers zu visualisieren. Der Platzhalter {ip} wird durch die IP des Besuchers ersetzt. <br>Beispiel: http://somewebsite.com/query?iplookup={ip}");


DEFINE('_JW_DESC_IGNORE_URI', "Sie können hier jede beliebige URI einfügen, die in der Statistik ignoriert werden soll. Die Nutzung von Platzhaltern (?) und Wildcards (*) ist möglich (Beispiel: /freel?n*).");

DEFINE('_JW_DESC_GOALS_NAME', "Legen Sie einen Namen für das Ziel fest. Dieser Name wird später in der Statistik angezeigt.");

DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Unter einer URI versteht man all das, was hinter Ihrem Domain-Namen steht. <br> (Beispiel: Die URL lautet http://www.codegravity.com/projects/, dann lautet die URI /projects/. Tragen Sie in diesem Fall z.B. folgenden Wert ein: <b>/projects*</b>");

DEFINE('_JW_DESC_GOALS_GET_VAR', "Die sog. GET-Variable ist eine Variable, die Sie in einer URL gewöhnlich hinter einem <b>?</b> oder einem <b>&</b>-Zeichen sehen <br> (Beispiel: http://www.codegravity.com/index.php?<u>name</u>=peter&<u>surname</u>=smith). <br> Sie können in diesem Feld auch Wildcards <b>*</b> einsetzen, um mehrere GET-Variablen zu erfassen <br> (Beispiel: <b>n*me</b>");

DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Geben Sie hier den Wert ein, der mit dem Wert aus der vorgenannten GET-Variable übereinstimmen muss. <br> (Beispiel: <b>p?t*r</b> erfasst die Werte peter, pater,...) ");

DEFINE('_JW_DESC_GOALS_POST_VAR', "Diese Funktion ist vergleichbar mit der vorstehenden GET-Funktion. Allerdings werden hier Werte überprüft, die ein User in Webformulare einträgt. <br> (Beispiel: Sollten Sie ein Formular auf ihrer Webseite einsetzen, welches ein Feld &lt;input type='text' name='<u>experiences</u>' /&gt; besitzt, so können Sie hier folgenden Wert eintragen:<b>exper*ces</b>");

DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Geben Sie hier den Wert ein, der mit dem Wert aus der vorgenannten POST-Variable übereinstimmen muss. <br> So können Sie beispielsweise die Eingabe von Java-Befehlen protokollieren (Beispiel: <b>*java*</b>.");

DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Seitentitel, der mit der Bedingung übereinstimmen muss. <br> (Beispiel: <b>*freelance programmers*</b>");

DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Name eines eingeloggten Besuchers. <br> (Beispiel: <b>psmith*</b>");

DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP, von welcher der Benutzer kommt. <br> (Beispiel: <b>201.9?.*.*</b>.");

DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL, von welcher der Benutzer kommt. <br> (Beispiel: <b>*www.google.*</b>.");

DEFINE('_JW_DESC_GOALS_REDIRECT', "Geben Sie ein bestimmte URL an, zu welcher der Benutzer im Falle des Bedingungseintritts weitergeleitet werden soll. <br> (Beispiel: <b>http://www.codegravity.com/goaway.html</b>. <br> Beachte: Die URL-Weiterleitung geht der IP-Blockierung vor.");

DEFINE('_JW_DESC_TRUNCATE_GOALS', "Maximale Anzahl der Zeichen, auf die ein Eintrag in der Ziele-Tabelle gekürzt werden soll");

DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Backlink zu codegravity.com. Sie können diesen abschalten, wir wären Ihnen aber sehr dankbar, wenn Sie den Link belassen würde. Vielen Dank");

DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Frontend-Anzeige der Länder-Statistik. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Falls Sie die Reihenfolge von Besucher- und Länderanzeige im Frontend-Modul ändern wollen: Bei Entfernen des Häckchens werden die Besucher zuerst angezeigt.");

DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Anzahl der Länder, die im Fontend angezeigt werden sollen.");

DEFINE('_JW_DESC_FRONTEND_VISITORS', "Frontend-Anzeige der Besucher pro Land. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Zeit in Sekunden to cache fetching of countries total in frontend");

DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Zeit in Sekunden to cache fetching of visitors in frontend");

DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Anzeige der Besucher im Frontend für: heute. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Frontend-Anzeige der Besucher für: gestern. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Frontend-Anzeige der Besucher für: diese Woche. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Frontend-Anzeige der Besucher für: letzte Woche. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Frontend-Anzeige der Besucher für: diesen Monat. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Frontend-Anzeige der Besucher für: letzten Monat. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Frontend-Anzeige aller Besucher seit der Installation von JoomlaWatch. Eine Änderung wird im Frontend erst wirksam nach Ablauf der für das CACHE_FRONTEND_ festgelegten Zeitspanne...");

DEFINE('_JW_DESC_LANGUAGE', "Auswahl der Sprachdatei. Diese Datei finden Sie unter <b>/components/com_joomlawatch/lang/</b>. Sollten Sie die Absicht haben, eine neue Sprachdatei zu erstellen, so prüfen Sie bitte erst, ob sich nicht auf der Projekt-Homepage bereits eine solche Sprachversion befindet. Sollten Sie für ihre Sprache keine Datei finden, müssen Sie die Sprachdatei 'english.php' kopieren und umbenennen (z.B. in 'german.php'). Dann müssen Sie in dieser Datei alle Key-Werte auf der rechten Seite übersetzen.");

DEFINE('_JW_DESC_GOALS', "Die Einrichtung eines Ziels erlaubt es Ihnen, spezifische Parameter festzulegen. Erfüllt ein Besucher diese Parameter, so wird sein Besuch als <b>Treffer</b> gezählt. Auf diesem Wege können Sie beispielsweise nachverfolgen, ob ein User eine spezifische URL aufgesucht hat, einen bestimmten Wert abgefragt hat, einen bestimmten Benutzernamen besitzt oder von einer bestimmten Adresse gekommen ist. Sie können Besucher, die einen der spezifizierten Parameter erfüllen, auch blockieren oder an eine bestimmte URL weiterleiten.");

DEFINE('_JW_DESC_GOALS_INSERT', "In den nachstehenden Felden (mit Ausnahme des Namens-Feldes) können Wildcards (<b>*</b> und Platzhalter (<b>?</b> verwendet werden. Beispiel: ?ear (entspricht: near, tear,...), p*r (entspricht: pr, peer, pear,...) ");

DEFINE('_JW_DESC_GOALS_BLOCK', "Gegen Sie eine <b>1</b> ein, falls Sie den Besucher blocken wollen. Der Besucher wird den Inhalt ihrer Seite nicht sehen. Er wird vielmehr - ohne weitergeleitet zu werden - lediglich die Nachricht erhalten, dass seine IP geblocket wurde. Ferner wird die entsprechende IP in die Statistik 'IP-Blockierung' aufgenommen. <br> (Beispielwert:<b>1</b>.");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Landeseinstellungen");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Landeskürzel in zwei Großbuchstaben (z.B.: <b>DE</b>)");
DEFINE('_JW_STATS_INTERNAL',"Intern");
DEFINE('_JW_STATS_FROM',"Von");
DEFINE('_JW_STATS_TO',"Bis");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Als Ziel hinzufügen");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Ziel für dieses Land hinzufügen");
DEFINE('_JW_MENU_REPORT_BUG',"Fehlerbericht senden");
DEFINE('_JW_GOALS_COUNTRY',"Land");

/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"If you want the names of the countries in the uppercase in frontend (Eg: GERMANY, UNITED KINGDOM instead of Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Time in seconds to cache fetching of users in frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Initial value shown in Total: in frontend. Useful when you migrated from other stat tool. (Eg.: 20000). Set back to 0 if you don't want to use this feature.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignore users listed in this textbox. One per line. (Eg.: myself {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Most active users today from total of");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Enable the bans based on the words from the spamword list below ?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Most common spam words used by spam bots. You can use the wildcards here, (Eg.: ph?rmac*). If the setting above is enabled, JoomlaWatch will check whether the attacker submitted a form (the HTTP POST request) on your website with some of these spam words. (Applies if the form loads the Joomla-based website only - forum, comments, but is quite effective to block spam bots which try to submit every possible form)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"A link in the frontend Users module - allows you to specify an URL, which is open when the user clicks the user name. Must contain the string {user}, which will be replaced by the actual user name. (Eg. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Keyphrases");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum values in history tab (Example: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In visits show only last page visited, not all");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In visits hide repetitive sitename in visited page title");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximum nuber of visitors to keep in database for Visit History. Be careful with this setting, if you have high traffic, it can grow really fast. Always check how much data the history table contains in Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Keep Database Tables on uninstall. Check this option before uninstall if you are doing an upgrade and want to keep your data.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "You'll receive nightly emails with reports for previous day, which you can read in the morning");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Email address to which you'll receive these reports");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Only include rows in email reports where percentage is higher than {value}. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Only include <b>positive one day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Only include <b>negative one day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Only include <b>positive seven day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Only include <b>negative seven day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Only include <b>positive thirty day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Only include <b>negative thirty day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functional in PRO version)</b> Enable this setting if you want to make the logo link rendered with attribute rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum characters of email row name. Change this if your email client message window is too small");

DEFINE('_JW_MENU_HISTORY', "History");
DEFINE('_JW_MENU_EMAILS', "Emails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"These IPs were blocked by anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Visitors History");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Showing only %d last records.
                To change this value, go to Settings -&gt; History &amp; Performance -&gt; HISTORY_MAX_DB_RECORDS . Be careful, this setting affects load times of the data below.  ");
DEFINE('_JW_MENU_BUG', "Report Bug");
DEFINE('_JW_MENU_FEATURE', "Request Feature");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Keywords");

DEFINE('_JW_BLOCKING_UNBLOCK',"unblock");
DEFINE('_JW_STATS_KEYPHRASE ',"Keyphrase");
DEFINE('_JW_STATUS_DATABASE',"Database status");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"table name");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rows");
DEFINE('_JW_STATUS_DATABASE_DATA',"data");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"total");

DEFINE('_JW_EMAIL_REPORTS',"Email Reports");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generated filtered email report from yesterday");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Email Value Filters");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"value");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-day change");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-day change");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-day change");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch has blocked %d spammer hits today, total: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blocked IP Adresses");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Settings");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX updates traffic");


DEFINE('_JW_HISTORY_PREVIOUS',"previous");
DEFINE('_JW_HISTORY_NEXT',"next");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Number of columns of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Number of rows of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Display country names or not");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Display flags first, then percents");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET inversed condition");
DEFINE('_JW_GOALS_POST_INVERSED', "POST inversed condition");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Title inversed condition");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Username inversed condition");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Came from inversed condition");

DEFINE('_JW_STATS_MAP', "Last Visit Map");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Please enter <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> key to display last visit map:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"store key");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Please enter valid ipinfodb key you obtained from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Submitted form fields:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameters:");
DEFINE('_JW_VISIT_ADD_PAGE'," Add page as goal");
DEFINE('_JW_VISIT_BLOCK_IP'," Block this IP Address");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Add this submitted form variable as goal");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Add this URL parameter as goal");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," WARNING: The value you entered is not a number. JoomlaWatch will not work properly!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; This is a 15-day Evaluation Version. Days Left: <b>%d</b>. Please purchase the lifetime <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Your trial version has expired. Please purchase JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"License activated successfully. Thank you");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: the license key and your domain don't match.</b><br/>Did you enter the same domain name into activation form as one you see below? Please contact: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"If you are seeing the message above for too long, your live site may be wrong.
                    Open the components/com_joomlawatch/config.php
                    uncomment, and set your actual live site. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Warning: site in your browser and live site in configuration: %s and %s don't match.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Set live site to: %s and continue...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Remove Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flow");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphs");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Components");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Write a ");

DEFINE('_JW_FLOW_TRAFFIC',"Traffic Flow");
DEFINE('_JW_FLOW_SELECT_PAGE',"Select page:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root outgoing links count:");
DEFINE('_JW_FLOW_NESTING',"Nesting level:");
DEFINE('_JW_FLOW_SCALE',"Scale:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Ad-free version");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Thank you very much for your donation!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registration key for your domain %s is: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Now you can remove backlink or hide JoomlaWatch logo in frontend from Settings ");


DEFINE('_JW_SIZES_LAST_CHECK',"Last check was performed on:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Size of component/module in /administrator directory");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Component");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Size");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Refresh All");

DEFINE('_JW_SIZEDATABASE_TABLE',"Table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Size");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Day Change");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Day Change");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Day Change");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"no data");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Refresh All");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Module");
DEFINE('_JW_SIZEMODULES_SIZE',"Size");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Refresh");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Last visit map ipinfodb.com key from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");

?>