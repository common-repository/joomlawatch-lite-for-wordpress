<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Menu główne
DEFINE('_JW_MENU_STATS', "Statystyki");
DEFINE('_JW_MENU_GOALS', "Cele");
DEFINE('_JW_MENU_SETTINGS', "Ustawienia");
DEFINE('_JW_MENU_CREDITS', "Twórcy");
DEFINE('_JW_MENU_FAQ', "Częste pytania");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentacja");
DEFINE('_JW_MENU_LICENSE', "Wersja bez reklam");
DEFINE('_JW_MENU_DONATORS', "Darczyńcy");
DEFINE('_JW_MENU_SUPPORT', "Wesprzyj JoomlaWatch i pozbądź się reklam.");

# Lewe okno panelu
DEFINE('_JW_VISITS_VISITORS', "Goście portalu");
DEFINE('_JW_VISITS_BOTS', "Boty");
DEFINE('_JW_VISITS_CAME_FROM', "Przekierowanie z");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Nie opublikowałeś modułu JoomlaWatch, dlatego statystyki nie są rejestrowane. Przejdź do działu Moduły i opublikuj ten moduł na wszystkich stronach portalu.");
DEFINE('_JW_VISITS_PANE_LOADING', "Trwa odczyt...");

# Prawe okno panelu
DEFINE('_JW_STATS_TITLE', "Tydzień");
DEFINE('_JW_STATS_WEEK', "Tydzień");
DEFINE('_JW_STATS_THIS_WEEK', "Bieżący tydzień");
DEFINE('_JW_STATS_UNIQUE', "unikalne");
DEFINE('_JW_STATS_LOADS', "przeładowania");
DEFINE('_JW_STATS_HITS', "kliknięcia");
DEFINE('_JW_STATS_TODAY', "Dzisiaj");
DEFINE('_JW_STATS_FOR', "&ndash;");
DEFINE('_JW_STATS_ALL_TIME', "ZBIORCZE");
DEFINE('_JW_STATS_EXPAND', "ROZWIŃ");
DEFINE('_JW_STATS_COLLAPSE', "ZWIŃ");
DEFINE('_JW_STATS_URI', "Strony");
DEFINE('_JW_STATS_COUNTRY', "Kraje");
DEFINE('_JW_STATS_USERS', "Użytkownicy");
DEFINE('_JW_STATS_REFERERS', "Przekierowania");
DEFINE('_JW_STATS_IP', "Adresy IP");
DEFINE('_JW_STATS_BROWSER', "Przeglądarki");
DEFINE('_JW_STATS_OS', "Systemy operacyjne");
DEFINE('_JW_STATS_KEYWORDS', "Słowa kluczowe");
DEFINE('_JW_STATS_GOALS', "Cele");
DEFINE('_JW_STATS_TOTAL', "Ogółem");
DEFINE('_JW_STATS_DAILY', "DZIENNE");
DEFINE('_JW_STATS_DAILY_TITLE', "Statystyki dzienne");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Statystyki zbiorcze");
DEFINE('_JW_STATS_LOADING', "Trwa odczyt...");
DEFINE('_JW_STATS_LOADING_WAIT', "Trwa odczyt danych. Czekaj...");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blokowanie IP");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Wprowadź adres IP");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Wprowadź adres IP, który chcesz zablokować (np. 217.242.11.54, aby zablokować pojedynczy adres, lub 217.*, aby zablokować wszystkie adresy pasujące do maski).");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Czy na pewno chcesz zablokować adres ");
DEFINE('_JW_STATS_PANE_LOADING', "Trwa odczyt...");

# Ustawienia
DEFINE('_JW_SETTINGS_TITLE', "Ustawienia");
DEFINE('_JW_SETTINGS_DEFAULT', "Domyślne");
DEFINE('_JW_SETTINGS_SAVE', "Zapisz");
DEFINE('_JW_SETTINGS_APPEARANCE', "Wygląd");
DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Historia i wydajność");
DEFINE('_JW_SETTINGS_ADVANCED', "Zaawansowane");
DEFINE('_JW_SETTINGS_IGNORE', "Ignoruj");
DEFINE('_JW_SETTINGS_BLOCKING', "Blokowanie");
DEFINE('_JW_SETTINGS_EXPERT', "Tryb eksperta");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Czy na pewno chcesz usunąć wszystkie statystyki?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Usuń wszystko");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Usuń wszystkie staytystyki...");
DEFINE('_JW_SETTINGS_LANGUAGE', "Język");
DEFINE('_JW_SETTINGS_SAVED', "Ustawienia zostały zapisane.");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Dodaj swój adres IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "do listy.");

# Inne 
DEFINE('_JW_TITLE', "AJAX. Monitor portalu Joomla!");
DEFINE('_JW_BACK', "Wstecz");
DEFINE('_JW_ACCESS_DENIED', "Nie masz uprawnień do oglądania tych danych!");
DEFINE('_JW_LICENSE_AGREE', "Akceptuję powyższe zasady.");
DEFINE('_JW_LICENSE_CONTINUE', "Kontynuuj");
DEFINE('_JW_SUCCESS', "Operacja zakończona powodzeniem.");
DEFINE('_JW_RESET_SUCCESS', "Usunięto wszystkie statystyki.");
DEFINE('_JW_RESET_ERROR', "Wystąpił błąd. Nie usunięto statystyk.");
DEFINE('_JW_CREDITS_TITLE', "Twórcy");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Statystyki dzienne i tygodniowe dla");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX - odmowa dostępu. Sprawdź te statystyki z domeny podanej w pliku configuration.php - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Być może zapomniałeś o wpisaniu liter www na początku domeny. Javasrcipt próbuje uzyskać dostęp do ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "z");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "co jest interpretowane jako inny adres.");

# Nagłówek
DEFINE('_JW_HEADER_DOWNLOAD', "Pobierz najnowsze aktualizacje z");
DEFINE('_JW_HEADER_CAST_YOUR', "Oddaj na nas swój");
DEFINE('_JW_HEADER_VOTE', "głos");

# Tooltip
DEFINE('_JW_TOOLTIP_CLICK', "Kliknij, aby wyświetlić tooltip...");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Wskaż myszą, aby wyświetlić tooltip");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "wczorajszy wzrost");
DEFINE('_JW_TOOLTIP_HELP', "Otwiera zewnętrzny system pomocy dla");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Zamknij to okno");
DEFINE('_JW_TOOLTIP_PRINT', "Drukuj");

# Cele
DEFINE('_JW_GOALS_INSERT', "Dodaj nowy cel");
DEFINE('_JW_GOALS_UPDATE', "Zmień cel nr");
DEFINE('_JW_GOALS_ACTION', "Akcja");
DEFINE('_JW_GOALS_TITLE', "Nowy cel");
DEFINE('_JW_GOALS_NEW', "Nowy cel");
DEFINE('_JW_GOALS_RELOAD', "Odśwież");
DEFINE('_JW_GOALS_ADVANCED', "Zaawansowane");
DEFINE('_JW_GOALS_NAME', "Nazwa");
DEFINE('_JW_GOALS_ID', "#");
DEFINE('_JW_GOALS_URI_CONDITION', "Warunek dla URI");
DEFINE('_JW_GOALS_GET_VAR', "Zmienna GET");
DEFINE('_JW_GOALS_GET_CONDITION', "Warunek dla zmiennej GET");
DEFINE('_JW_GOALS_POST_VAR', "Zmienna POST");
DEFINE('_JW_GOALS_POST_CONDITION', "Warunek dla zmiennej POST");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Warunek dla tytułu");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Warunek dla nazwy użytkownika");
DEFINE('_JW_GOALS_IP_CONDITION', "Warunek dla adresu IP");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Warunek dla adresu wywołania");
DEFINE('_JW_GOALS_BLOCK', "Blokuj");
DEFINE('_JW_GOALS_REDIRECT', "Przekieruj do URL");
DEFINE('_JW_GOALS_HITS', "Kliknięcia");
DEFINE('_JW_GOALS_ENABLED', "Odblokowane");
DEFINE('_JW_GOALS_EDIT', "Edytuj");
DEFINE('_JW_GOALS_DELETE', "Usuń");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Skasujesz wszystkie statystyki dla tego celu. Czy na pewno chcesz usunąć cel nr");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Kraje");
DEFINE('_JW_FRONTEND_VISITORS', "Goście");
DEFINE('_JW_FRONTEND_TODAY', "Dzisiaj");
DEFINE('_JW_FRONTEND_YESTERDAY', "Wczoraj");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Bieżący tydzień");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Poprzedni tydzień");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Bieżący miesiąc");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Poprzedni miesiąc");
DEFINE('_JW_FRONTEND_TOTAL', "Ogółem");

# Opisy ustawień 
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch działa w trybie debuggera. Pozwala on na wykrycie błędów. Aby wyłączyć ten tryb, zmień wartość JOOMLAWATCH_DEBUG w pliku /components/com_joomlawatch/config.php Z 1 na 0.");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Maksymalna liczba wierszy wyświetlanych po rozwinięciu statystyk.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Liczba kliknięć powodująca usunięcie adresu IP z historii (usuwane są adresy, dla których liczba kliknięć w ostatnich dniach jest mniejsza od podanej tutaj).");
DEFINE('_JW_DESC_STATS_URL_HITS', "Liczba kliknięć powodująca usunięcie adresu URL z historii (usuwane są adresy, dla których liczba kliknięć w ostatnich dniach jest mniejsza od podanej tutaj).");
DEFINE('_JW_DESC_IGNORE_IP', "Adresy IP, które będą ignorowane w statystykach. Adresy należy rozdzielić znakami nowego wiersza. Można używać znaku gwiazdki, np. 192.* spowoduje ignorowanie adresów: 192.168.51.31, 192.168.16.2, itp.");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Czas odświeżania dla użytkowników (w milisekundach). Standardowo 2000. Zmieniać po dokładnym rozważeniu. Po zmianie odświeżyć panel JoomlaWatch.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Czas odświeżania dla użytkowników (w milisekundach). Standardowo 4000. Zmieniać po dokładnym rozważeniu. Po zmianie odświeżyć panel JoomlaWatch.");
DEFINE('_JW_DESC_MAXID_BOTS', "Liczba odwiedzin botów przechowywanych w bazie danych.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Liczba rzeczywistych odwiedzin przechowywanych w bazie danych.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Liczba botów wyświetlanych w panelu.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Liczba gości wyświetlanych w panelu.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maksymalna liczba znaków wyświetlanych w długich tytułach i adresach URL.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Maksymalna liczba znaków wyświetlanych w prawej części panelu.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Czas przechowywania statystyk w bazie danych (w dniach). 0 = bezterminowo.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Ma zastosowanie, jeżeli czas lokalny różni się od czasu serwera. Liczba godzin różnicy.");
DEFINE('_JW_DESC_WEEK_OFFSET', "Przesunięcie tygodnia: timestamp/(3600*24*7). Daje w wyniku numer tygodnia liczony od 1.1.1970. Wartość wykorzystywana w celu rozpoczęcia zliczania od poniedziałku.");
DEFINE('_JW_DESC_DAY_OFFSET', "Przesunięcie dnia: timestamp/(3600*24). Daje w wyniku numer dnia liczony od 1.1.1970. Wartość wykorzystywana w celu rozpoczęcia zliczania od godziny 00:00.");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Zaznacz, aby w module JoomlaWatch Agent wyświetlić pusty obrazek o wymiarach 1x1 px.");
DEFINE('_JW_DESC_IP_STATS', "Zaznacz, aby zbierać statytsyki dla adresów IP. W niektórych krajach dłuższe przechowywanie adresów IP jest zabronione. Wykorzystujesz na własną odpowiedzialność.");
DEFINE('_JW_DESC_HIDE_ADS', "To ustawienie ukrywa reklamy w panelu. Zachowując wyświetlanie reklam, wspomagasz rozwój tego komponentu. Dziękujemy za pomoc.");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Usuń zaznaczenie, aby wyświetlać tooltip po wskazaniu myszą (a nie po kliknięciu).");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Domyślnie: 'REDIRECT_URL'; można zmienić na 'SCRIPT_URL', jeżeli logi zbierają tylko dane o pliku index.php.");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Informacja wyświetlana w przypadku zablokowania adresu IP użytkownika.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Tooltip &ndash; szerokość w pikselach.");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Tooltip &ndash; wysokość w pikselach.");
DEFINE('_JW_DESC_TOOLTIP_URL', "Adres strony pokazującej lokalizację IP. Wpis {ip} zostanie zastąpiony adresem IP użytkownika. Przykład zastosowania: <b>http://somewebsite.com/query?iplookup={ip}</b>.");
DEFINE('_JW_DESC_IGNORE_URI', "URI, które mają być ignorowane w statystykach. Można stosować symbole globalne (gwiazdka i pytajnik). Przykład zastosowania: <b>/freel?n*</b>.");
DEFINE('_JW_DESC_GOALS_NAME', "Nazwa celu. Będzie ona widoczna w panelu statystyk.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Ciąg znaków po nazwie domeny. Np. dla <b>http://www.codegravity.com/projects/</b> URI to: <b>/projects/</b>. Przykładowe zastosowanie: <b>/projects*</b>.");
DEFINE('_JW_DESC_GOALS_GET_VAR', "Zmienna GET jest widoczna w adresie URL, zazwyczaj po znaku ? lub &amp;. Przykład: http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Aby poszukiwać wielu zmiennych, można stosować znak <b>*</b> (gwiazdka). Przykładowe zastosowanie: <b>n*me</b>.");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Warunek dla wartości z poprzedniego pola. Przykładowe zastosowanie: <b>p?t*r</b>.");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Podobnie jak poprzednio, ale dla wartości przesyłanych za pośrednictwem formularzy. Przykład: jeżeli na stronie znajduje się formularz zawierający pole &lt;input type='text' name='<u>experiences</u>' /&gt;, zmienną opisuje fraza: <b>exper*ces</b>.");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', " Warunek dla wartości z poprzedniego pola. Przykładowe zastosowanie: <b>*java*</b>.");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Poszukiwany tytuł strony. Przykładowe zastosowanie: <b>*freelance programmers*</b>.");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Poszukiwana nazwa użytkownika. Przykładowe zastosowanie: <b>psmith*</b>.");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "Adres IP użytkownika. Przykładowe zastosowanie: <b>201.9?.*.*</b>.");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "Adres URL użytkownika. Przykładowe zastosowanie: <b>*www.google.*</b>.");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Adres, pod który ma być przekierowany użytkownik. <b>To ustawienie ma wyższy priorytet niż blokowanie.</b> Przykładowe zastosowanie: <b>http://www.codegravity.com/goaway.html</b>.");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Liczba znaków w tabeli celów.");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Odnośnik do strony codegravity.com. Można go wyłączyć, ale będziemy wdzięczni za jego zachowanie. Dziękujemy.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Czy wyświetlać kraje w module JoomlaWatch Visitors? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Czy zmienić kolejność wyświetlania gości / krajów w module JoomlaWatch Visitors? Usuń zaznaczenie, aby wyświetlać gości na pierwszej pozycji.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Liczba krajów wyświetlanych w module JoomlaWatch Visitors.");
DEFINE('_JW_DESC_FRONTEND_VISITORS', " Czy wyświetlać gości w module JoomlaWatch Visitors? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Czas odświeżania danych krajów w module JoomlaWatch Visitors (w sekundach).");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', " Czas odświeżania danych gości w module JoomlaWatch Visitors (w sekundach).");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Czy w module JoomlaWatch Visitors wyświetlać dane gości z dnia dzisiejszego? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Czy w module JoomlaWatch Visitors wyświetlać dane gości z dnia wczorajszego? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Czy w module JoomlaWatch Visitors wyświetlać dane gości z bieżącego tygodnia? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Czy w module JoomlaWatch Visitors wyświetlać dane gości z ubiegłego tygodnia? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Czy w module JoomlaWatch Visitors wyświetlać dane gości z bieżącego miesiąca? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Czy w module JoomlaWatch Visitors wyświetlać dane gości z ubiegłego miesiąca? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Czy w module JoomlaWatch Visitors wyświetlać liczbę odwiedzin zarejestrowaną od instalacji JoomlaWatch? Zmiana będzie widoczna po czasie zapisanym w zmiennej CACHE_FRONTEND_.");
DEFINE('_JW_DESC_LANGUAGE', "Plik języka wykorzystywany do wyświetlania komunikatów w modułach portalu oraz w panelu admina. Wszystkie pliki językowe są zapisane w folderze /components/com_joomlawatch/lang/. Jeżeli chcesz utworzyć nowy plik, najpierw sprawdź stronę projektu. Jeśli nie ma tam pliku Twojego języka, skopiuj plik english.php, dadając mu nową nazwę, np. polish-utf8.php. Następnie przetłumacz wszystkie napisy i zapisz plik w folderze plików językowych.");
DEFINE('_JW_DESC_GOALS', "Cele powalają na określenie szczegółowych parametrów interesujących Cię statystyk. Jeżeli wystąpi spełnienie określonych przez Ciebie warunków, zostanie zwiększony licznik dla danego celu.<br />Poprzez odpowiednie wykorzystanie celów możesz sprawdzać, czy goście odwiedzają określone adresy URL, wysyłają określone dane, czy zanotowano wizyty użytkowników o określonych nazwach, wywołania z określonych adresów itp. Możesz również blokować dostęp określonym użytkownikom lub przekierowywać ich do innych adresów URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "We wszystkich polach oprócz pola nazwy możesz używać symboli globalnych (gwiazdki i pytajnika), np. ?aj (pasujące frazy: dzisiaj, wczoraj itp.),  p*e (pasujące frazy: pe, prawie, ponownie itp.)");
DEFINE('_JW_DESC_GOALS_BLOCK', "Ustaw 1, jeżeli chcesz zablokować użytkownika. Zablokowany użytkownik nie widzi zawartości strony, a jedynie komunikat o blokadzie. Jego adres IP jest dopisywany do listy zablokowanych. Przykładowe zastosowanie: <b>1</b>.");

/* Nowe tłumaczenia */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Warunek dla kraju");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Dwuznakowy kod kraju DUŻYMI LITERAMI, np. <b>PL</b>.");
DEFINE('_JW_STATS_INTERNAL',"Przekierowania wewnętrzne");
DEFINE('_JW_STATS_FROM',"Z");
DEFINE('_JW_STATS_TO',"Do");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Dodaj do celów");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Dodaj cel dla tego kraju...");
DEFINE('_JW_MENU_REPORT_BUG',"Zgłoś błąd");
DEFINE('_JW_GOALS_COUNTRY',"Kraj");


/* Tłumaczenia dla wersji 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Zaznacz, aby w module JoomlaWatch Visitors wyświetlać nazwy krajów pisane dużymi literami.");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Czas odświeżania danych użytkowników w module JoomlaWatch Visitors (w sekundach).");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Początkowa wartość całkowitej liczby użytkowników wyświetlanej w module JoomlaWatch Visitors. Ustawienie przydatne w przypadku przejścia z innego systemu statystyk.");
DEFINE('_JW_DESC_IGNORE_USER', "Użytkownicy, których dane mają być ignorowane. Jeden wpis w wierszu. Przykładowe zastosowanie: <b>stan</b> {nowy wiersz} <b>mark_*</b>.");
DEFINE('_JW_FRONTEND_USERS_MOST', "Najbardziej aktywni użytkownicy bieżącego dnia.");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Czy umożliwić automatyczne blokowanie użytkowników wykorzystujących słowa z poniższej listy?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Słowa najczęściej wykorzystywane przez boty rozsyłające spam. Można wykorzystywać symbole globalne, np. ph?rmac*.<br /><br />Jeżeli pole SPAMWORD_BANS_ENABLED jest zaznaczone, JoomlaWatch sprawdzi, czy nadawca przesłał dane poprzez polecenie POST, wykorzystując formularz na Twojej stronie. <br /><br />Lista znajduje zastosowanie, jeśli formularz korzysta z zasobów Joomli (forum, komentarze), jest również przydatna do blokowania innych prób przesyłania formularzy ze spamem.");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anty-spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Odnośnik w module JoomlaWatch Users. Adres URL otwierany po kliknięciu nazwy użytkownika. Musi zawierać frazę {user}, która zostanie zastąpiona właściwą nazwą użytkownika. Przykład zastosowania: <b>index.php?option=com_comprofiler&task=userProfile&user={user}</b>.");

/* Added by Stan */
DEFINE('_JW_REGISTERED_VISITS', "Liczba zarejestrowanych gości: ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Keyphrases");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum values in history tab (Example: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In visits show only last page visited, not all");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In visits hide repetitive sitename in visited page title");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximum nuber of visitors to keep in database for Visit History. Be careful with this setting, if you have high traffic, it can grow really fast. Always check how much data the history table contains in Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Keep Database Tables on uninstall. Check this option before uninstall if you are doing an upgrade and want to keep your data.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "You'll receive nightly emails with reports for previous day, which you can read in the morning");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Email address to which you'll receive these reports");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Only include rows in email reports where percentage is higher than {value}. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Only include <b>positive one day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Only include <b>negative one day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Only include <b>positive seven day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Only include <b>negative seven day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Only include <b>positive thirty day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Only include <b>negative thirty day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functional in PRO version)</b> Enable this setting if you want to make the logo link rendered with attribute rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum characters of email row name. Change this if your email client message window is too small");

DEFINE('_JW_MENU_HISTORY', "History");
DEFINE('_JW_MENU_EMAILS', "Emails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"These IPs were blocked by anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Visitors History");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Showing only %d last records.
                To change this value, go to Settings -&gt; History &amp; Performance -&gt; HISTORY_MAX_DB_RECORDS . Be careful, this setting affects load times of the data below.  ");
DEFINE('_JW_MENU_BUG', "Report Bug");
DEFINE('_JW_MENU_FEATURE', "Request Feature");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Keywords");

DEFINE('_JW_BLOCKING_UNBLOCK',"unblock");
DEFINE('_JW_STATS_KEYPHRASE ',"Keyphrase");
DEFINE('_JW_STATUS_DATABASE',"Database status");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"table name");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rows");
DEFINE('_JW_STATUS_DATABASE_DATA',"data");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"total");

DEFINE('_JW_EMAIL_REPORTS',"Email Reports");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generated filtered email report from yesterday");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Email Value Filters");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"value");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-day change");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-day change");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-day change");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch has blocked %d spammer hits today, total: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blocked IP Adresses");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Settings");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX updates traffic");


DEFINE('_JW_HISTORY_PREVIOUS',"previous");
DEFINE('_JW_HISTORY_NEXT',"next");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Number of columns of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Number of rows of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Display country names or not");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Display flags first, then percents");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET inversed condition");
DEFINE('_JW_GOALS_POST_INVERSED', "POST inversed condition");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Title inversed condition");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Username inversed condition");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Came from inversed condition");

DEFINE('_JW_STATS_MAP', "Last Visit Map");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Please enter <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> key to display last visit map:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"store key");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Please enter valid ipinfodb key you obtained from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Submitted form fields:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameters:");
DEFINE('_JW_VISIT_ADD_PAGE'," Add page as goal");
DEFINE('_JW_VISIT_BLOCK_IP'," Block this IP Address");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Add this submitted form variable as goal");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Add this URL parameter as goal");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," WARNING: The value you entered is not a number. JoomlaWatch will not work properly!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; This is a 15-day Evaluation Version. Days Left: <b>%d</b>. Please purchase the lifetime <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Your trial version has expired. Please purchase JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"License activated successfully. Thank you");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: the license key and your domain don't match.</b><br/>Did you enter the same domain name into activation form as one you see below? Please contact: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"If you are seeing the message above for too long, your live site may be wrong.
                    Open the components/com_joomlawatch/config.php
                    uncomment, and set your actual live site. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Warning: site in your browser and live site in configuration: %s and %s don't match.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Set live site to: %s and continue...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Remove Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flow");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphs");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Components");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Write a ");

DEFINE('_JW_FLOW_TRAFFIC',"Traffic Flow");
DEFINE('_JW_FLOW_SELECT_PAGE',"Select page:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root outgoing links count:");
DEFINE('_JW_FLOW_NESTING',"Nesting level:");
DEFINE('_JW_FLOW_SCALE',"Scale:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Ad-free version");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Thank you very much for your donation!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registration key for your domain %s is: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Now you can remove backlink or hide JoomlaWatch logo in frontend from Settings ");


DEFINE('_JW_SIZES_LAST_CHECK',"Last check was performed on:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Size of component/module in /administrator directory");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Component");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Size");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Refresh All");

DEFINE('_JW_SIZEDATABASE_TABLE',"Table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Size");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Day Change");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Day Change");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Day Change");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"no data");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Refresh All");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Module");
DEFINE('_JW_SIZEMODULES_SIZE',"Size");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Refresh");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Last visit map ipinfodb.com key from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");

?>
