﻿<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistik");
DEFINE('_JW_MENU_GOALS', "Mål");
DEFINE('_JW_MENU_SETTINGS', "Inställningar");
DEFINE('_JW_MENU_CREDITS', "Erkännande");
DEFINE('_JW_MENU_FAQ', "FAQ");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentation");
DEFINE('_JW_MENU_LICENSE', "Reklamfri Licens");
DEFINE('_JW_MENU_DONATORS', "Donatorer");
DEFINE('_JW_MENU_SUPPORT', "Support JoomlaWatch för att få bort reklamen i backend.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Senaste Besökare");
DEFINE('_JW_VISITS_BOTS', "Bottar");
DEFINE('_JW_VISITS_CAME_FROM', "Kom från");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Din JoomlaWatch modul är inte publiceras! Ingen statistik kommer att registreras. Publicera modulen på alla sidor.");
DEFINE('_JW_VISITS_PANE_LOADING', "Laddar besökare...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Besökstatistiken för vecka");
DEFINE('_JW_STATS_WEEK', "Vecka");
DEFINE('_JW_STATS_THIS_WEEK', "denna vecka");
DEFINE('_JW_STATS_UNIQUE', "unika");
DEFINE('_JW_STATS_LOADS', "laddningar");
DEFINE('_JW_STATS_HITS', "träffar");
DEFINE('_JW_STATS_TODAY', "idag");
DEFINE('_JW_STATS_FOR', "för");
DEFINE('_JW_STATS_ALL_TIME', "Alltid");
DEFINE('_JW_STATS_EXPAND', "expandera");
DEFINE('_JW_STATS_COLLAPSE', "kollapsa");
DEFINE('_JW_STATS_URI', "Sidor");
DEFINE('_JW_STATS_COUNTRY', "Länder");
DEFINE('_JW_STATS_USERS', "Användare");
DEFINE('_JW_STATS_REFERERS', "Refererar");
DEFINE('_JW_STATS_IP', "IPs");
DEFINE('_JW_STATS_BROWSER', "Webbläsare");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "Nyckelord");
DEFINE('_JW_STATS_GOALS', "Mål");
DEFINE('_JW_STATS_TOTAL', "Totalt");
DEFINE('_JW_STATS_DAILY', "Dagligen");
DEFINE('_JW_STATS_DAILY_TITLE', "Daglig statistik");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Statistik totalt");
DEFINE('_JW_STATS_LOADING', "laddar...");
DEFINE('_JW_STATS_LOADING_WAIT', "laddar... vänligen vänta");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blockerat IP");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Välj IP manuellt");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Skriv in IP-nummer som du vill blockera. (eg. 217.242.11.54 or 217.* or 217.242.* för att blockera alla IP som matchar wildcard)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Riktig toggle blockering av ");
DEFINE('_JW_STATS_PANE_LOADING', "Laddar statistik...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Inställningar");
DEFINE('_JW_SETTINGS_DEFAULT', "Default");
DEFINE('_JW_SETTINGS_SAVE', "Spara");
DEFINE('_JW_SETTINGS_APPEARANCE', "Utseende");
DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Historik &amp; Prestation");
DEFINE('_JW_SETTINGS_ADVANCED', "Avancerad");
DEFINE('_JW_SETTINGS_IGNORE', "Ignorera");
DEFINE('_JW_SETTINGS_BLOCKING', "Blockera");
DEFINE('_JW_SETTINGS_EXPERT', "Expert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Vill du verkligen återställa all statistik och besöksdata?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Återställ allt");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Återställ all statistik &amp; besöks data");
DEFINE('_JW_SETTINGS_LANGUAGE', "Språk");
DEFINE('_JW_SETTINGS_SAVED', "Inställningarna sparades");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Lägg till ditt IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "till listan.");

# Other / mostly general
DEFINE('_JW_TITLE', "En real-tid AJAX Joomla övervakare");
DEFINE('_JW_BACK', "Tillbaka");
DEFINE('_JW_ACCESS_DENIED', "Du har inga privillegier för att se detta!");
DEFINE('_JW_LICENSE_AGREE', "Jag godkänner licensens &amp; villkor ovan");
DEFINE('_JW_LICENSE_CONTINUE', "Fortsätta");
DEFINE('_JW_SUCCESS', "Operationen lyckades");
DEFINE('_JW_RESET_SUCCESS', "All statistik och besöksdata raderades");
DEFINE('_JW_RESET_ERROR', "Datan raderades INTE, någonting gick fel");
DEFINE('_JW_CREDITS_TITLE', "Erkännande");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Daglig och veckovis statistik av");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX rättighetern nekades: Vänligen se statistiken från din domän specifierad i configuration.php i din Joomla installation - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Kanske glömde du www. framför ditt domännamn. Ditt javascript försööker få access ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "från");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "varför försöker den tro att det är en annan domän.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Få den senaste koden för extensions från");
DEFINE('_JW_HEADER_CAST_YOUR', "Ge din");
DEFINE('_JW_HEADER_VOTE', "Röst");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Klicka för att visa tooltip");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Hovra musen över tooltip");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "gårdagens&apos;s ökar");
DEFINE('_JW_TOOLTIP_HELP', "Öppnar extern online hjälp för");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Stäng detta fönster");
DEFINE('_JW_TOOLTIP_PRINT', "SKriv ut");

# Goals
DEFINE('_JW_GOALS_INSERT', "Lägg till ett nytt mål");
DEFINE('_JW_GOALS_UPDATE', "Updatera ett målsnummer.");
DEFINE('_JW_GOALS_ACTION', "Aktivitet");
DEFINE('_JW_GOALS_TITLE', "Nytt mål");
DEFINE('_JW_GOALS_NEW', "Nytt mål");
DEFINE('_JW_GOALS_RELOAD', "Uppdatera");
DEFINE('_JW_GOALS_ADVANCED', "Avancerad");
DEFINE('_JW_GOALS_NAME', "Namn");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "URI tillstånd");
DEFINE('_JW_GOALS_GET_VAR', "FÅ var");
DEFINE('_JW_GOALS_GET_CONDITION', "Få tillstånd");
DEFINE('_JW_GOALS_POST_VAR', "POSTA Var");
DEFINE('_JW_GOALS_POST_CONDITION', "POSTA Tillstånd");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Titel tillstånd");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Användarnamn tillstånd");
DEFINE('_JW_GOALS_IP_CONDITION', "IP Tillstånd");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Kom från tillstånd");
DEFINE('_JW_GOALS_BLOCK', "Blockera");
DEFINE('_JW_GOALS_REDIRECT', "Redirect till URL");
DEFINE('_JW_GOALS_HITS', "Träffar");
DEFINE('_JW_GOALS_ENABLED', "Tillåt");
DEFINE('_JW_GOALS_EDIT', "Ändra");
DEFINE('_JW_GOALS_DELETE', "Radera");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Du kommer förlora den senaste statistiken för detta mål. Villd u verkligen radera mål nr.");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Länder");
DEFINE('_JW_FRONTEND_VISITORS', "Besökare");
DEFINE('_JW_FRONTEND_TODAY', "Idag");
DEFINE('_JW_FRONTEND_YESTERDAY', "Igår");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Denna vecka");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Senaste veckan");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Denna månad");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Senaste månad");
DEFINE('_JW_FRONTEND_TOTAL', "Totalt");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch är i debug mode. På detta sätt kan du upptäcka fel. För att ändra, vänligen ändra värdet JOOMLAWATCH_DEBUG in /components/com_joomlawatch/config.php från 1 till 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Max rader som visas när statistiken är i expanderbart läge.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Alla IP addresser som har färre träffar än detta värde kommer raderas från IP-historiken.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Alla URLs som har färre träffar än detta värde kommer raderas från IP-historiken.");
DEFINE('_JW_DESC_IGNORE_IP', "Exkludera specifikt IP från statistiken. Separera med ny rad. Du kan välja wildcards här. <br/>Eg. 192.* will ignore 192.168.51.31, 192.168.16.2, etc..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Besökarstatistik uppdateras i tid (milisekunder), default är 2000, var försiktig med detta. Uppdatera sedan JoomlaWatch i back-end.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Besökarstatistik uppdateras i tid (milisekunder), default är 4000, var försiktig med detta. Uppdatera sedan JoomlaWatch i back-end..");
DEFINE('_JW_DESC_MAXID_BOTS', "Hur många bottarbesök som lagras i databasen.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Hur många besökare som lagras i databasen.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Hur många bottar som du vill se i back-end.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Hur många besökare som du vill se i back-end.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maximalt antal tecken som visas i långa titlar och uris.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Maximalt antal tecken som visas i den högra statistikspanelen.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Dagar som statistiken lagras i databasen, 0 = oändligt.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "När du är i en annan tidszon än din hostserver. (positivt eller negativt värde i timmar)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Inställning vecka, inställningen/(3600*24*7) ger veckonummer från 1.1.1970, denna inställning är en rättning för att få veckan att starta med en måndag ");
DEFINE('_JW_DESC_DAY_OFFSET', "Inställning dag, inställningen/(3600*24) ger dagnummmer från 1.1.1970, denna inställning är en rättning för att få start från 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "För att använda en tom 1x1px icon i front-end");
DEFINE('_JW_DESC_IP_STATS', "För att tillåta statstik för IP-adresser. I vissa länder är det förbjudet att lagra IP-adresser i en databas. Använd på egen risk.");
DEFINE('_JW_DESC_HIDE_ADS', "Denna inställning gömmer reklamen i backend, om den verkligen stör dig. Om du har kvar den, hjälper du oss att forsätta utvecklingen av denna komponent. Tack");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Uncheck, om du vill visa tooltip med att 'hovra', iställer för att klicka.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Default är 'REDIRECT_URL', vilket är standard om du använder url rewriting, kan ändras till 'SCRIPT_URL' om den bara loggar index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Meddelandet som visas för användare som är blockerade på sidan.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Tooltip bredd");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Tooltip höjd");
DEFINE('_JW_DESC_TOOLTIP_URL', "Du kan lägga till länk här, för att visa besökarnas IP. {ip} kommer visa besökarens IP. Eg. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Du kan skriva in URI som du inte vill ta med i statistiken. Du kan använda wildcards (* and ?) här. Eg.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Specifiera namnet på målet här. Detta namn kommer att visas i statistiken.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Allt som är efter ditt domännamn. För http://www.codegravity.com/projects/ URI är: /projects/ (Example to use: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET variabeln är en variabel som du kanse URL vanligtvis efter a ? or &amp; sign. Eg. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Du kan också se <u>*</u> i detta fält för scanna alla värden. (Example to use: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Här måste du specifiera en match för värdet från förra fältet. (Example to use: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Liknande, men kontrollerar värdet från skickades formulär. Så när du har formulär på din sida, så har detta ett fält &lt;input type='text' name='<u>experiences</u>' /&gt;. (Exempel för att använda: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "En matchning från värdet från detta POST fält. Eg. vi vill se om användaren har erfarenhet av java. (Example to use: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "En titel på en sida som måste matchas. (Exempel för att använda: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Ett namn för inloggade användare. (Exempel för att använda: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP som användaren kommer från: (Exempel för att använda: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "En URL som besökaren kommer från. (Exempel för att använda: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Användaren är redirected till en URL specifierad av dig. Har en högre prioritet än 'blocking': (Exempel för att använda: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Hur många tecken som kapas av i måltabellen");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Tillbaka länk till codegravity.com, du kan frångå, men vi uppskattar om du behåller länken. Tack");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Visar länders totalstatistik i modulen i frontend. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Om du vill ändra ordningen för Besökare/Länder i frontend. Uncheck , och Besökare kommer visas först.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Antal länder som visas i frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Visa länders besökare i modulen i frontend. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Tid i sekunder för cache Totalt länder i frontend");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Tid i sekunder för cache Totalt besökare i frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "För att visa besökare i frontend för: idag. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "För att visa besökare i för: igår. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "För att visa besökare i frontend för: denna vecka. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "För att visa besökare i frontend för: senaste veckan. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "För att visa besökare i frontend för: denna månad. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "För att visa besökaren i frontend för: senaste månad. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "För att visa totalt antal besökare sedan installationen av JoomlaWatch. Om ändrat, denna inställning kommer att fungera först efter tiden är satt i CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "Språkfil som ska användas. De placeras i /components/com_joomlawatch/lang/. Om du vill skapa en ny språkfil, besök först Joomlawatchs hemsida, och om du inte finner den språkfil du söker, kopiera bara default english.php till eg. german.php och placera den i mappen /lang. Sedan, översätt värdena till höger.");
DEFINE('_JW_DESC_GOALS', "Mål tillåter dig specifiera speciella parameterar. När dessa paramterar matchas, ökar måltalet. På detta sätt kan du övervaka om användarna har besökt en specifik URL, postat ett specifikt värde, har ett specifikt användarnamn eller kom från en specifik adress. Du kan också blockera eller redirect sådana användare till en viss URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "I alla fält, förutom namn, kan du använda * och ? som wildcards. Exempel för att använda: ?ear (will match: near, tear, ..),  p*r (will match: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Sätt till 1, om du vill blockera besökaren. Besökaren kommer inte se resten av innehållet, bara meddelandet om att han var blockerad - utan någon redirect och hans IP läggs till 'blockerad' statistiken (Exempel för att använda: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Länder villkort");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "2-tecken kod för länder med stora tecken (Eg: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Inkommande");
DEFINE('_JW_STATS_FROM',"Från");
DEFINE('_JW_STATS_TO',"Till");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Lägg till i Mål");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Lägg till Mål för detta land");
DEFINE('_JW_MENU_REPORT_BUG',"Rapportera bugg eller fel");
DEFINE('_JW_GOALS_COUNTRY',"Land");

/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Om du vill se ländernas namn med versaler i frontend (Eg: TYSKLAND, StorBritannien istället för Tyskland, Storbritannien)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Tid i sekunder för cache att fånga upp användare i frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Ursprungsvärde för Totalt: i frontend. Detta är användningsbart om du exempelvis migrerar från ett annat statistikverktyg. (Eg.:20000). Välj 0 om du inte vill använda denna funktion.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignorera användare i denna lista. En för varje rad. (Eg.: mig själv {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Mest aktiva användare för idag från Totalt");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Aktivera blockerade användare baserat på orden i Spam-ordslistan ?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Vanligaste spam-orden från spam bottar.Du kan använda wildcards, (Eg.: ph?rmac*). Om inställningarna ovan är aktiverade kommer JoomlaWatch kontrollera om attackerna skickade ett formulär innehållande dessa ord (HTTP POST förfrågan). (Detta är tillämpningsbart när processerna använder Joomla - forum, kommentarer, men alla attacker kan undvikas för alla försök att skicka formulär via spam bottar)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"En länk i användarmodulen i frontend - möjliggör att specifiera en 'klickbar URL' via användarnamnet. Stringen måste bestå av {user}, vilken kommer ersättas av användarnamnet. (Eg. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Keyphrases");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum values in history tab (Example: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In visits show only last page visited, not all");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In visits hide repetitive sitename in visited page title");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximum nuber of visitors to keep in database for Visit History. Be careful with this setting, if you have high traffic, it can grow really fast. Always check how much data the history table contains in Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Keep Database Tables on uninstall. Check this option before uninstall if you are doing an upgrade and want to keep your data.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "You'll receive nightly emails with reports for previous day, which you can read in the morning");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Email address to which you'll receive these reports");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Only include rows in email reports where percentage is higher than {value}. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Only include <b>positive one day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Only include <b>negative one day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Only include <b>positive seven day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Only include <b>negative seven day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Only include <b>positive thirty day</b> change values in email reports higher than {value} percent. Set to 0 if you don't want to use this feature <i>(example: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Only include <b>negative thirty day</b> change values in email reports lower than {value} percent. Set to 0 if you don't want to use this feature <i>(example: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(functional in PRO version)</b> Enable this setting if you want to make the logo link rendered with attribute rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum characters of email row name. Change this if your email client message window is too small");

DEFINE('_JW_MENU_HISTORY', "History");
DEFINE('_JW_MENU_EMAILS', "Emails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"These IPs were blocked by anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Visitors History");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Showing only %d last records.
                To change this value, go to Settings -&gt; History &amp; Performance -&gt; HISTORY_MAX_DB_RECORDS . Be careful, this setting affects load times of the data below.  ");
DEFINE('_JW_MENU_BUG', "Report Bug");
DEFINE('_JW_MENU_FEATURE', "Request Feature");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Keywords");

DEFINE('_JW_BLOCKING_UNBLOCK',"unblock");
DEFINE('_JW_STATS_KEYPHRASE ',"Keyphrase");
DEFINE('_JW_STATUS_DATABASE',"Database status");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"table name");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rows");
DEFINE('_JW_STATUS_DATABASE_DATA',"data");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"total");

DEFINE('_JW_EMAIL_REPORTS',"Email Reports");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generated filtered email report from yesterday");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Email Value Filters");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"value");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-day change");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-day change");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-day change");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch has blocked %d spammer hits today, total: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blocked IP Adresses");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Settings");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX updates traffic");


DEFINE('_JW_HISTORY_PREVIOUS',"previous");
DEFINE('_JW_HISTORY_NEXT',"next");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Number of columns of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Number of rows of countries");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Display country names or not");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Display flags first, then percents");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET inversed condition");
DEFINE('_JW_GOALS_POST_INVERSED', "POST inversed condition");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Title inversed condition");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Username inversed condition");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Came from inversed condition");

DEFINE('_JW_STATS_MAP', "Last Visit Map");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Please enter <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> key to display last visit map:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"store key");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Please enter valid ipinfodb key you obtained from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Submitted form fields:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameters:");
DEFINE('_JW_VISIT_ADD_PAGE'," Add page as goal");
DEFINE('_JW_VISIT_BLOCK_IP'," Block this IP Address");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Add this submitted form variable as goal");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Add this URL parameter as goal");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," WARNING: The value you entered is not a number. JoomlaWatch will not work properly!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; This is a 15-day Evaluation Version. Days Left: <b>%d</b>. Please purchase the lifetime <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Your trial version has expired. Please purchase JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"License activated successfully. Thank you");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: the license key and your domain don't match.</b><br/>Did you enter the same domain name into activation form as one you see below? Please contact: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"If you are seeing the message above for too long, your live site may be wrong.
                    Open the components/com_joomlawatch/config.php
                    uncomment, and set your actual live site. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Warning: site in your browser and live site in configuration: %s and %s don't match.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Set live site to: %s and continue...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Remove Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flow");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphs");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Components");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Write a ");

DEFINE('_JW_FLOW_TRAFFIC',"Traffic Flow");
DEFINE('_JW_FLOW_SELECT_PAGE',"Select page:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Root outgoing links count:");
DEFINE('_JW_FLOW_NESTING',"Nesting level:");
DEFINE('_JW_FLOW_SCALE',"Scale:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Ad-free version");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Thank you very much for your donation!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registration key for your domain %s is: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Now you can remove backlink or hide JoomlaWatch logo in frontend from Settings ");


DEFINE('_JW_SIZES_LAST_CHECK',"Last check was performed on:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Size of component/module in /administrator directory");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Component");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Size");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Refresh All");

DEFINE('_JW_SIZEDATABASE_TABLE',"Table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Size");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Day Change");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Day Change");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Day Change");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"no data");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Refresh All");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Module");
DEFINE('_JW_SIZEMODULES_SIZE',"Size");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Refresh");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Last visit map ipinfodb.com key from: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Force Timezone Offset");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Update");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Upgrade");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Not available in free version, please check the license tab");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Words Ban Enable");
DEFINE('_JW_SPAMWORD_LIST', "Spam Words List");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Hide Repetitive Title");
DEFINE('_JW_TRUNCATE_VISITS', "Truncate Visits");
DEFINE('_JW_TRUNCATE_STATS', "Truncate Stats");
DEFINE('_JW_TRUNCATE_GOALS', "Truncate Goals");
DEFINE('_JW_LIMIT_BOTS', "Limit Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Width");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Height");
DEFINE('_JW_TOOLTIP_URL', "Tooltip URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip OnClick");
DEFINE('_JW_IP_STATS', "IP stats");
DEFINE('_JW_IPINFODB_KEY', "IP Info DB key ");
DEFINE('_JW_ONLY_LAST_URI', "Only Last URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Front End Hide Logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Front End No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Front End no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Front User links");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Front End countries first");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Front End Countries Name");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Front End Countreis Upper case");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Front End Countries Flag First ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Front End Countries Num");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Front End Countries Max Colums");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Front End Countries Max Rows");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Front End Visitors Today ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Front End Visitors Yesterday ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Front End Visitors This week ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Front End Visitors Last week ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Front End Visitors This Month ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Front End Visitors Last Month");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Front End Hide Visitors Total");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Front End Total Initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "History Max Values");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "History Max records");
DEFINE('_JW_UPDATE_TIME_VISITS', "Update Time Visits");
DEFINE('_JW_UPDATE_TIME_STATS', "Update Time stats");
DEFINE('_JW_STATS_MAX_ROWS', "Stats Max rows");
DEFINE('_JW_STATS_IP_HITS', "Stats IP hits");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid Visitors");
DEFINE('_JW_STATS_KEEP_DAYS', "Stats Keep days ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache Front End Countries ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache Front End Visitors ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Uninstall Keep Data ");
DEFINE('_JW_IGNORE_IP', "Ignore IP");
DEFINE('_JW_IGNORE_URI', "Ignore URI");
DEFINE('_JW_IGNORE_USER', "Ignore User");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocking Message");
DEFINE('_JW_SERVER_URI_KEY', "Server URI key");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Front End Visitors Total Initial");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Records");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," To make the blocking effective, you need to publish JoomlaWatch agent BEFORE any content or forms. Eg. on left side in your template.
                    <br/>
                    Go to Module Manager -> JoomlaWatch agent -> select position as left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Nightly email reports enabled");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Watch installation demo");

?>