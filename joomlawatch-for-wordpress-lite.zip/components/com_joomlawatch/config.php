<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );

/* This is the main file with basic settings */


/* LIVE SITE:
* (remove //) of the following line to override the live site setting:
*/

# define('JOOMLAWATCH_LIVE_SITE','/');

define('JOOMLAWATCH_VERSION', "1.2.18 BETA");
define('JOOMLAWATCH_REVISION', "507");

define('JOOMLAWATCH_DEBUG', 0);

define('JOOMLAWATCH_SERVER_DAYLIGHT_SAVING', 0);

define('JOOMLAWATCH_STATS_MAX_ROWS', '20');
define('TYPE_JOOMLAWATCH_STATS_MAX_ROWS', "number");

define('JOOMLAWATCH_STATS_IP_HITS', '20');
define('TYPE_JOOMLAWATCH_STATS_IP_HITS', "number");

define('JOOMLAWATCH_STATS_URL_HITS', '20');
define('TYPE_JOOMLAWATCH_STATS_URL_HITS', "number");

define('JOOMLAWATCH_IGNORE_IP', '   ');
define('TYPE_JOOMLAWATCH_IGNORE_IP', "text");

define('JOOMLAWATCH_IGNORE_USER', '   ');
define('TYPE_JOOMLAWATCH_IGNORE_USER', "text");

define('JOOMLAWATCH_UPDATE_TIME_VISITS', "2000");
define('TYPE_JOOMLAWATCH_UPDATE_TIME_VISITS', "number");

define('JOOMLAWATCH_UPDATE_TIME_STATS', "4000");
define('TYPE_JOOMLAWATCH_UPDATE_TIME_STATS', "number");

define('JOOMLAWATCH_MAXID_BOTS', 40);
define('TYPE_JOOMLAWATCH_MAXID_BOTS', "number");

define('JOOMLAWATCH_MAXID_VISITORS', 40);
define('TYPE_JOOMLAWATCH_MAXID_VISITORS', "number");

define('JOOMLAWATCH_LIMIT_BOTS', 5);
define('TYPE_JOOMLAWATCH_LIMIT_BOTS', "number");

define('JOOMLAWATCH_LIMIT_VISITORS', 60);
define('TYPE_JOOMLAWATCH_LIMIT_VISITORS', "number");

define('JOOMLAWATCH_TRUNCATE_VISITS', 60);
define('TYPE_JOOMLAWATCH_TRUNCATE_VISITS', "number");

define('JOOMLAWATCH_TRUNCATE_STATS',15);
define('TYPE_JOOMLAWATCH_TRUNCATE_STATS', "number");

define('JOOMLAWATCH_STATS_KEEP_DAYS', 90);
define('TYPE_JOOMLAWATCH_STATS_KEEP_DAYS', "number");

define('JOOMLAWATCH_TIMEZONE_OFFSET', '0');
define('TYPE_JOOMLAWATCH_TIMEZONE_OFFSET', "number");

define('JOOMLAWATCH_WEEK_OFFSET', -0.56547619);
define('TYPE_JOOMLAWATCH_WEEK_OFFSET', "number");

define('JOOMLAWATCH_DAY_OFFSET', 0.0416667);
define('TYPE_JOOMLAWATCH_DAY_OFFSET', "number");

define('JOOMLAWATCH_FRONTEND_HIDE_LOGO', 0);
define('TYPE_JOOMLAWATCH_FRONTEND_HIDE_LOGO', "checkbox");

define('JOOMLAWATCH_IP_STATS', 0);
define('TYPE_JOOMLAWATCH_IP_STATS', "checkbox");

define('JOOMLAWATCH_HIDE_ADS', 0);
define('TYPE_JOOMLAWATCH_HIDE_ADS', "checkbox");

define('JOOMLAWATCH_TOOLTIP_ONCLICK', 'On');
define('TYPE_JOOMLAWATCH_TOOLTIP_ONCLICK', "checkbox");

define('JOOMLAWATCH_SERVER_URI_KEY', 'REDIRECT_URL');

define('TYPE_JOOMLAWATCH_BLOCKING_MESSAGE', "text");

define('JOOMLAWATCH_TOOLTIP_WIDTH', 1000);
define('TYPE_JOOMLAWATCH_TOOLTIP_WIDTH', "number");

define('JOOMLAWATCH_TOOLTIP_HEIGHT', 768);
define('TYPE_JOOMLAWATCH_TOOLTIP_HEIGHT', "number");

define('JOOMLAWATCH_TOOLTIP_URL', "http://www.netip.de/search?query={ip}");

define('JOOMLAWATCH_IGNORE_URI', '');
define('TYPE_JOOMLAWATCH_IGNORE_URI', "text");

define('JOOMLAWATCH_TRUNCATE_GOALS', 20);

define('JOOMLAWATCH_FRONTEND_NO_BACKLINK', 0);
define('TYPE_JOOMLAWATCH_FRONTEND_NO_BACKLINK', "checkbox");

define('JOOMLAWATCH_FRONTEND_NOFOLLOW', 0);
define('TYPE_JOOMLAWATCH_FRONTEND_NOFOLLOW', "checkbox");

define('JOOMLAWATCH_FRONTEND_COUNTRIES', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_COUNTRIES', "checkbox");

define('JOOMLAWATCH_FRONTEND_COUNTRIES_UPPERCASE', 0);
define('TYPE_JOOMLAWATCH_FRONTEND_COUNTRIES_UPPERCASE', "checkbox");

define('JOOMLAWATCH_FRONTEND_COUNTRIES_NUM', 10);
define('TYPE_JOOMLAWATCH_FRONTEND_COUNTRIES_NUM', "number");

define('JOOMLAWATCH_FRONTEND_VISITORS', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS', "checkbox");

define('JOOMLAWATCH_FRONTEND_USER_LINK', '');

define('JOOMLAWATCH_CACHE_FRONTEND_COUNTRIES', "300");

define('JOOMLAWATCH_CACHE_FRONTEND_VISITORS', "300");

define('JOOMLAWATCH_CACHE_FRONTEND_USERS', "300");

define('JOOMLAWATCH_FRONTEND_VISITORS_TODAY', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_TODAY', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_YESTERDAY', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_YESTERDAY', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_THIS_WEEK', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_THIS_WEEK', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_LAST_WEEK', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_LAST_WEEK', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_THIS_MONTH', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_THIS_MONTH', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_LAST_MONTH', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_LAST_MONTH', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_TOTAL', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_VISITORS_TOTAL', "checkbox");

define('JOOMLAWATCH_FRONTEND_COUNTRIES_FIRST', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_COUNTRIES_FIRST', "checkbox");

define('JOOMLAWATCH_FRONTEND_VISITORS_TOTAL_INITIAL', 0);

define('JOOMLAWATCH_LICENSE_ACCEPTED', 0);

define('JOOMLAWATCH_BLOCKING_MESSAGE', "Your IP address was blocked by JoomlaWatch, please contact the system administrator");

define('JOOMLAWATCH_SPAMWORD_LIST', "
000 per day
000 per month
000 per week
100% free
addresses on cd
adipex
advicer
affiliate program
all natural
amazing stuff
an invitation to
any future mailing
as seen on
auto email removal
avoid bankruptcy
baccarrat
bad credit
bankruptcy
be a millionaire
be amazed
be your own boss
beneficiary
big bucks
big money
bill 1618
billing address
billion
billion dollars
blackjack
bllogspot
booker
brand new pager
broadcast e-mail
bulk email
burn fat
buy direct
buying judgments
byob
cable converter
call free
call now
calling creditors
cancel at any time
cannot be combined with any other offer
car-rental-e-site
car-rentals-e-site
carisoprodol
cash back
cash bonus
cashcashcash
casino
casinos
cell phone cancer scam
cents on the dollar
chain letter
chatroom
check or money order
cialis
claim your
click this link
click to remove
click to remove mailto
collect child support
compare rates
compete for your business
confidentially on all orders
consolidate debt and credit
consolidate today
coolcoolhu
coolhu
copy accurately
copy dvds
credit approval
credit bureaus
credit card offers
credit counseling
credit-card-debt
credit-report-4u
cures baldness
cwas
cyclen
cyclobenzaprine
dainty
dating-e-site
day-trading
debt consolidation
debt-consolidation
debt-consolidation-consultant
different reply to
dig up dirt on friends
direct email
direct marketing
discreetordering
discusses search engine listings
doctor approved pill
don't hesitate
dormant
double your income
drastically reduced
duty-free
dutyfree
e-mail marketing
earn $
earn extra cash
earn per week
eliminate bad credit
eliminate debt
email harvest
email marketing
enlarge penis
equity line of credit
equityloans
expect to earn
explode your business
extra income
f r e e
fantastic deal
fast cash
fast viagra delivery
financial freedom
financially independent
find out anything
fioricet
flowers-leading-site
follow the link
for free
for instant access
for just $ (some amt)
for only $
free cell phone
free consultation
free dvd
free gift
free grant money
free investment
free leads
free membership
free money
free offer
free preview
free priority mail
free to the first
freenet
freenet-shopping
full refund
gambling-
get rich
get started now
gift certificate
great offer
guarantee
hair loss
hair-loss
have you been turned down?
health-insurancedeals-4u
herbal remedies
hidden assets
holdem
holdempoker
holdemsoftware
holdemtexasturbowilson
home based
home based business
home business
home employment
home equity
homebased business
homeequityloans
homefinance
hotel-dealse-site
hotele-site
hotelse-site
human growth hormone
if only it were that easy
if you wish to be removed
in accordance with laws
incest
income from home
increase sales
increase traffic
increase your sales
incredible deal
information you requested
insurance
insurance-quotesdeals-4u
insurancedeals-4u
investment decision
it's effective
join millions of american
jrcreations
largest payoff
laser printer
levitra
liens
life insurance
limited time offer
limited time only
long distance phone offer
look younger
loosest slots
lose 10 pounds
lose weight spam
lower interest rates
lower monthly payment
lowest mortgage interest rates
lowest price
luxury car
mail in order form
mailing list
mailinglist
maintained
major credit cards
marketing solutions
mass email
meet singles
member stuff
message contains disclaimer
money making
money problems
month trial offer
more internet traffic
mortgage rates
mortgage-4-u
mortgagequotes
multi level marketing
name brand
new customers only
new domain extensions
nigerian
no age restrictions
no catch
no claim forms
no cost
no credit check
no disappointment
no experience
no gimmick
no inventory
no investment
no medical exams
no middleman
no more debt
no obligation
no purchase necessary
no questions asked
no selling
no strings attached
non secured
not intended
not mlm
not multi-level
not multilevel
off shore
offer expires
offer only available
offers coupon
offers extra cash
offers free (often stolen) passwords
once in lifetime
one hundred percent free
one hundred percent guaranteed
one time mailing
online biz opportunity
online casino
online pharmacy
online-gambling
onlinegambling-4u
only $
opt in
opt out
opt-out
optout
order by fax
order by phone
order within
orders shipped by priority mail
ottawavalleyag
outstanding values
over weight
ownsthis
palm-texas-holdem-game
paxil
penis
penis enlarge
pennies a day
perpetual
pharmacy
phentermine
poker-chip
potential earnings
poze
presently
print form signature
print out and fax
produced and sent out
profits
pure profit
pussy
rate quote
rates slashed
real thing
reciprocal
referring url
refinance
refinance home
removal instructions
remove in the subject line
remove me
remove subject
remove yourself
removed from future mailing
removed in subject line
removes wrinkles
rental-car-e-site
reply remove subject
reply to this message
reply with
requires initial investment
reserves the right
retirement business
reverses aging
ringtones
risk free
roulette
round the world
safeguard notice
satisfaction guaranteed
save $
save big money
save up to
score with babes
search engine listings
second mortgage
section 301
serious cash
shemale
single deck black jack
slot-machine
special promotion
stock disclaimer statement
stop balding
stop future mailing
stop snoring
student loans
texas-holdem
this e-mail complies
thorcarlson
to be removed
top-e-site
top-site
tramadol
trim-spa
ultram
vacation giveaway
valeofglamorganconservatives
very low-cost
viagra
video poker
vioxx
weight loss
wow gold
xanax
you win
you won
you're already approved
zolus
");

define('JOOMLAWATCH_SPAMWORD_BANS_ENABLED', 0);
define('TYPE_JOOMLAWATCH_SPAMWORD_BANS_ENABLED', "checkbox");

define('TYPE_JOOMLAWATCH_SPAMWORD_LIST', "largetext");


define('JOOMLAWATCH_LANGUAGE', 'english');
define('TYPE_JOOMLAWATCH_LANGUAGE', "select");

define('JOOMLAWATCH_HISTORY_MAX_VALUES', 20);
define('TYPE_HISTORY_MAX_VALUES', "text");

define('JOOMLAWATCH_HISTORY_MAX_DB_RECORDS', 200);
define('TYPE_HISTORY_MAX_DB_RECORDS', "text");


define('JOOMLAWATCH_ONLY_LAST_URI', false);
define('TYPE_JOOMLAWATCH_ONLY_LAST_URI', "checkbox");

define('JOOMLAWATCH_HIDE_REPETITIVE_TITLE', false);
define('TYPE_JOOMLAWATCH_HIDE_REPETITIVE_TITLE', "checkbox");

define('JOOMLAWATCH_UNINSTALL_KEEP_DATA', false);
define('TYPE_JOOMLAWATCH_UNINSTALL_KEEP_DATA', "checkbox");

define('JOOMLAWATCH_EMAIL_REPORTS_ENABLED', false);
define('TYPE_JOOMLAWATCH_EMAIL_REPORTS_ENABLED', "checkbox");

define('JOOMLAWATCH_EMAIL_SEO_REPORTS_ENABLED', false);
define('TYPE_JOOMLAWATCH_EMAIL_SEO_REPORTS_ENABLED', "checkbox");

define('JOOMLAWATCH_EMAIL_REPORTS_ADDRESS', "@");

define('JOOMLAWATCH_EMAIL_PERCENT_HIGHER_THAN', 0);

define('JOOMLAWATCH_EMAIL_ONE_DAY_CHANGE_POSITIVE', 0);
define('JOOMLAWATCH_EMAIL_ONE_DAY_CHANGE_NEGATIVE', 0);
define('JOOMLAWATCH_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', 0);
define('JOOMLAWATCH_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', 0);
define('JOOMLAWATCH_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', 0);
define('JOOMLAWATCH_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', 0);

define('JOOMLAWATCH_EMAIL_NAME_TRUNCATE',40);


define('JOOMLAWATCH_FRONTEND_COUNTRIES_MAX_COLUMNS',1);
define('JOOMLAWATCH_FRONTEND_COUNTRIES_MAX_ROWS',10);

define('JOOMLAWATCH_FRONTEND_COUNTRIES_NAMES', 1);
define('TYPE_JOOMLAWATCH_FRONTEND_COUNTRIES_NAMES', "checkbox");

define('JOOMLAWATCH_FRONTEND_COUNTRIES_FLAGS_FIRST', 0);
define('TYPE_JOOMLAWATCH_FRONTEND_COUNTRIES_FLAGS_FIRST', "checkbox");

define('JOOMLAWATCH_FLOW_DEFAULT_OUTGOING_LINKS_COUNT', 5);
define('JOOMLAWATCH_FLOW_DEFAULT_NESTING_LEVEL', 2);


define('DB_KEY_BROWSER',1);
define('DB_KEY_COUNTRY',2);
define('DB_KEY_GOALS',3);
define('DB_KEY_HITS',4);
define('DB_KEY_INTERNAL',5);
define('DB_KEY_IP',6);
define('DB_KEY_KEYWORDS',7);
define('DB_KEY_LOADS',8);
define('DB_KEY_OS',9);
define('DB_KEY_REFERERS',10);
define('DB_KEY_UNIQUE',11);
define('DB_KEY_URI',12);
define('DB_KEY_USERS',13);
define('DB_KEY_KEYPHRASE',14);
define('DB_KEY_URI2KEYPHRASE',15);

define('DB_KEY_SIZE_DB',101);
define('DB_KEY_SIZE_COM',102);
define('DB_KEY_SIZE_MOD',103);

define('JOOMLAWATCH_WARNING_THRESHOLD', 20);

/* number of visit a keyphrase has to get to be considered as unimportant */
define('JOOMLAWATCH_UNIMPORTANT_KEYPHRASE_THRESHOLD', 5);
define('JOOMLAWATCH_DAYS_TO_KEEP_UNIMPORTANT_KEYPHRASES', 7);

define('JOOMLAWATCH_MAP_OPENMAP', 1);
// not using google map by default
define('JOOMLAWATCH_MAP_GOOGLEMAP', 0);

$keysArray = array('goals', 'referers', 'internal', 'keyphrase', 'keywords', 'uri',  'users', 'country', 'ip', 'browser', 'os');

//upgrade.xml path
define('TEMP_JOOMLAWATCH_UPDATE_FILE_URL',"http://www.codegravity.com/update/joomlawatch/update.xml");

//upgrade <script> files path
define('TEMP_JOOMLAWATCH_SCRIPT_POSTION',"http://localhost/joomla/upgrade/joomlawatch/script/");

//zip file path including 4 files:com_joomlawatch.zip,mod_joomlawatch_agent.zip,mod_joomlawatch_users.zip and mod_joomlawatch_visitors.zip
define('TEMP_JOOMLAWATCH_LASTESTZIP_POSTION',"http://www.codegravity.com/update/joomlawatch/");

define('JOOMLAWATCH_UNKNOWN_COUNTRY',"xx");

define('JOOMLAWATCH_TABLES_TO_OPTIMIZE',
serialize(array(
    "#__joomlawatch_config",
    "#__joomlawatch_flow",
    "#__joomlawatch_goals",
    "#__joomlawatch_heatmap",
    "#__joomlawatch_history",
    "#__joomlawatch_info",
    "#__joomlawatch_internal",
    "#__joomlawatch_ip2c",
    "#__joomlawatch_keyphrase",
    "#__joomlawatch_uri",
    "#__joomlawatch_uri2keyphrase",
    "#__joomlawatch_uri2title",
    "#__joomlawatch_uri_history",
    "#__joomlawatch_uri_post")
));


?>