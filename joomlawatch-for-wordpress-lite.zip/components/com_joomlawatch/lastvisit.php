<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

header("Content-type: text/xml");

include_once("includes.php");
$joomlaWatch = new JoomlaWatch();
$joomlaWatch->block->checkPermissions();
$ip = $joomlaWatch->visit->getLastIp();
$location = $joomlaWatch->visit->ip2Country($ip);

?>
<markers>
	<?php echo "<marker name=\"".$location['city'].", ".$location['country']."\" address=\"".$location['ipAdress']."\" lat=\"".
	$location['latitude']."\" lng=\"".
	$location['longitude']."\" type=\"visitor\"/>"; ?>
</markers>