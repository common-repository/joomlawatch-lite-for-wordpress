<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<script type="text/javascript" src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix(); ?>components/com_joomlawatch/js/jxml.js"></script>
<script type="text/javascript" src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix(); ?>components/com_joomlawatch/js/jdownloadurl.js"></script>
<?php if ($this->joomlaWatch->config->getConfigValue("JOOMLAWATCH_MAP_GOOGLEMAP")) { ?>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<?php } ?>
<script type="text/javascript" src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix(); ?>components/com_joomlawatch/js/maps.js.php?rand=<?php echo $this->joomlaWatch->config->getRand();?>&env=<?php echo ($this->joomlaWatch->config->getEnvironment());?>"></script>

<?php
if (!$this->joomlaWatch->config->checkLiveSite()) {
    ?>
<div style="border: 1px solid red; width:40%; padding: 10px;">
    <?php echo sprintf(""._JW_ADMINBODY_LIVE_SITE."", "<b>". JoomlaWatchEnvFactory::getEnvironment()->getRootSite() ."</b>", "<b>". $this->joomlaWatch->config->getLiveSiteWithSuffix() ."</b>" ); ?> <br/><br/>
    <a href="<?php JoomlaWatchEnvFactory::getEnvironment()->getRootSite();?>index.php?option=com_joomlawatch&task=resetLiveSite&rand=<?php echo $this->joomlaWatch->config->getRand();?>"><?php echo sprintf(""._JW_ADMINBODY_SET_LIVE_SITE."", JoomlaWatchEnvFactory::getEnvironment()->getRootSite() ); ?></a>
</div>
<?php
    }
?>

<?php echo $this->joomlaWatch->block->checkBlocked($_SERVER['REMOTE_ADDR']); ?>

<center>
    <table border='0' cellpadding='2' width='100%' <?php echo $this->joomlaWatch->helper->getTooltipOnEventHide(); ?> >
        <tr>
            <td rowspan="2" id="visits" valign='top' align='left' width='80%'>
                <?php echo _JW_VISITS_PANE_LOADING; ?>
                <br/><br/>
                <div id='loading' style='width: 200px; border: 1px solid black; background-color: yellow; padding:5px; display:none;'>
                    <?php echo ""._JW_VIEW_ADMINBODY_LONG_MESSAGE."" ?>
                </div>
            </td>
            <td valign="top">
                <?php include("lastvisitmap.php");?>
            </td>
        </tr>
        <tr>
            <td id="stats" valign='top'  align='left'>
                <?php echo _JW_STATS_PANE_LOADING; ?>
            </td>
        </tr>
    </table>
</center>

<?php
if (!$this->joomlaWatch->config->isFree()) {
    if ($this->joomlaWatch->config->getConfigValue("JOOMLAWATCH_IPINFODB_KEY")) {
        ?>
    <?php if ($this->joomlaWatch->config->getConfigValue("JOOMLAWATCH_MAP_OPENMAP")) { ?>
        <script src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/js/OpenLayers/OpenLayers.js"></script>
        <?php } ?>
    <script type='text/javascript'>
            <?php if ($this->joomlaWatch->config->getConfigValue("JOOMLAWATCH_MAP_GOOGLEMAP")) { ?>
        GoogleMapLoad();
            <?php } ?>
            <?php if ($this->joomlaWatch->config->getConfigValue("JOOMLAWATCH_MAP_OPENMAP")) { ?>
        OpenMapLoad();
            <?php } ?>
        /*
            try {
            setTimeout("makeLoadingDisappear()", 5000);
            } catch (e) {
                // suppress
            }
        */
    </script>
    <?php }
}
?>


<script type="text/javascript">sendLastIdReq();</script>

