<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchJoomlaEnv implements JoomlaWatchEnv {

    function getDatabase()
    {
        return JFactory::getDBO();
    }

    function getRequest()
    {
        return new JRequest();
    }

    function & getURI()
    {
        return JFactory::getURI();
    }

    function isSSL()
    {
        return JFactory::getURI()->isSSL();
    }

    function getRootSite()
    {
        return JURI::root();
    }

    function getAdminDir()
    {
        return "administrator";
    }

    function getCurrentUser()
    {
        return JFactory::getUser();
    }


    function getTimezoneOffset()
    {
        $config = new JConfig();
        return $config->offset;
    }

    function getEnvironmentSuffix()
    {
        return "";
    }

    function renderLink($task, $otherParams)
    {
        return $this->getRootSite().$this->getAdminDir()."/index.php?option=com_joomlawatch&task=".$task."&action=".$otherParams;
    }

    function getUser()
    {
        global $mainframe;
        if (version_compare( JVERSION, '1.5.0', 'ge' )) {
            /* joomla 1.5 or above */
            return JFactory::getUser();
        } else {
            return @ $mainframe->getUser();
        }

    }

    function getTitle()
    {
        global $mainframe;
        if (version_compare( JVERSION, '1.5.0', 'ge' )) {
            /* joomla 1.5 or above */
            $mydoc =& JFactory::getDocument();
            return $mydoc->getTitle();
        } else if (version_compare( JVERSION, '1.0.0', 'ge' )) {
            /* joomla 1.0 */
            return $mainframe->getPageTitle();
        }
    }

    function getUsername()
    {
        $user = JFactory::getUser();
        return $user->username;
    }


    function sendMail($recipient, $sender, $recipient, $subject, $body, $true, $cc, $bcc, $attachment, $replyto, $replytoname)
    {
        JUtility::sendMail($recipient, $sender, $recipient, $subject, $body, 1, $cc, $bcc, $attachment, $replyto, $replytoname);
    }

    function getDbPrefix()
    {
        $config = new JConfig;
        return $config->dbprefix;
    }
}
?>