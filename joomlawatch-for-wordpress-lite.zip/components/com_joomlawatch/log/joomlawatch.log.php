<?php die( 'Restricted access' ); ?>
