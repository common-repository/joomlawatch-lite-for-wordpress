=== JoomlaWatch LITE for Wordpress ===
Contributors: matto3c
Donate link: http://www.codegravity.com/
Tags: admin, AJAX, page, pages, plugin, sidebar, spam, stats, widget, wordpress, countries, visitors, tracking, maps, location, geolocation, statistics, spam
Requires at least: 3.2.1.
Tested up to: 3.2.1.
Stable tag: 1.2.18

Popular visitor live tracking component ported from Joomla. Features: live stats, graphs, goal definition, history, bad words filter, email reports

== Description ==
Popular visitor live tracking component ported from Joomla. JoomlaWatch allows you to watch your joomla visitors live stats and bots in real-time from the administration back-end. Specially their IP addresses, countries they come from, geographical location on a map, which pages they are viewing, their browser and operating system, it creates daily and all-time stats from these information plus unique, pageload and total hits statistics. Furthermore, you can block harmful IP addresses, see blocked attempts stats, evaluate the trend charts, and create goals based on many parameters. In the front-end, it displays the top countries, user and visit information for certain periods of time. ==

== Installation ==
Manual installation choosing the joomlawatch.zip archive

1. In adminstration, choose Plugins -> Add new
2. Click Upload
3. Click "Browse ..", find joomlawatch.zip which you downloaded from codegravity.com
4. Then "Install now"
5. You are still in plugins section, near "JoomlaWatch for WP beta" click "Activate"
6. On left "JoomlaWatch" link will appear, click this link and after confirmation you should see the backend
7. Open your wordpress frontend - you should see a JoomlaWatch icon logo, users and visitors module
8. Back in administration, you should see a new recorded visit

Enjoy!


== Screenshots ==

http://www.codegravity.com/img/joomlawatch_for_wordpress_activation.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_frontend.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_livestats.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_map.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_history.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_antispam.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_emails.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_goals.png
http://www.codegravity.com/img/joomlawatch_for_wordpress_settings.png

Here's the live demo from Joomla
http://www.codegravity.com/demo/joomlawatch/1.2.14/

The functionality of LITE version should be more or less the same as one for Joomla.

I will record the live demo for wordpress soon!


== Frequently Asked Questions ==

Please read http://www.codegravity.com/faq/

== Changelog ==

= 1.2.18 BETA =
Initial release for wordpress CMS !
This is the BETA version, it's not that much tested, please report possible problems to:
http://www.codegravity.com/bug/

== Upgrade Notice ==

Initial version, no upgrade possible.

== Arbitrary section ==